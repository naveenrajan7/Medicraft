<?php
require('db_connection.php');
$uname=$_POST['username'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$pass=$_POST['password'];

$sql_u = "SELECT * FROM users WHERE email='$email'";
$sql_e = "SELECT * FROM users WHERE mobile='$phone'";
$res_u = mysqli_query($connection, $sql_u);
$res_e = mysqli_query($connection, $sql_e);

if (mysqli_num_rows($res_u) > 0) {
  	//echo '<script>alert("Sorry... email already taken")</script>'; 
    echo "<script>
        alert('Sorry...email already taken');
        window.location.href='addadmin.html';
    </script>";
}if(mysqli_num_rows($res_e) > 0){
  	//echo '<script>alert("Sorry... phone number already taken")</script>';
     echo "<script>
        alert('Sorry...phone number already taken');
        window.location.href='addadmin.html';
    </script>";
 
}else {


$query="insert into users values('$uname','$email','$phone','$pass','admin')";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
echo "<script>
								alert('Admin Added');
									window.location.href='admin.php';
								</script>";
}
?>
