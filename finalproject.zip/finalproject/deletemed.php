<?php
require('db_connection.php');
$refno = $_POST['refid'];

$query="select medname,brand,quantity from `sellmedicine` WHERE referenceno='$refno'";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
$row = mysqli_fetch_array($result);
$medname=$row['medname'];
$brand=$row['brand'];
$oldqty=$row['quantity'];
$query1="select qty from `tblproduct` WHERE name='$medname' and brand='$brand'";
$result1= mysqli_query($connection, $query1) or die(mysqli_error($connection));
$row1 = mysqli_fetch_array($result1);
$qty=$row1['qty'];
$newqty=(int)$qty-(int)$oldqty;
$query2="UPDATE `tblproduct` SET `qty`='$newqty'WHERE name='$medname' and brand='$brand'";
$result2= mysqli_query($connection, $query2) or die(mysqli_error($connection));
echo "<script>
								alert('Deleted');
									window.location.href='admin.php';
</script>";
?>