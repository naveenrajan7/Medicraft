<?php  
 require('db_connection.php');
$refno = $_POST['referenceno'];
$amt = $_POST['amt'];
$comment = $_POST['comment'];
$query="UPDATE `sellmedicine` SET `amount`='$amt', comment='$comment', pharmacyvalidate='1' WHERE referenceno='$refno'";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));

echo "<script>
								alert('Vaildated');
								window.location.href='delivery.php';
								</script>";

//echo "success";

?>