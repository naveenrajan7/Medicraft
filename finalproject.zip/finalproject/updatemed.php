<?php
require('db_connection.php');
$id=$_POST['id'];
$medname=$_POST['medname'];
$image=$_POST['image'];
$qty=$_POST['qty'];
$price=$_POST['price'];
$ngocost=$_POST['ngocost'];
$des=$_POST['des'];
$code=$_POST['refid'];

$query2="update tblproduct set id='$id',name='$medname',image='$image',qty='$qty',price='$price',ngocost='$ngocost', description='$des' where code='$code'";
$result2 = mysqli_query($connection, $query2) or die(mysqli_error($connection));
echo "<script>
alert('Updated Stock');
window.location.href='admin.php';
</script>";
//echo "sucess";
?>