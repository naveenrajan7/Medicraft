-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2021 at 08:53 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medicraft`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `docname` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `description` varchar(300) NOT NULL,
  `skype` varchar(50) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `availability` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`docname`, `password`, `description`, `skype`, `mobile`, `email`, `availability`) VALUES
('Vithyasakar', '12345', 'Heart Specialist', 'skype:live:.cid.e203a8627ba0f0ea?call', '9790766216', 'nitesh5000@gmail.com', 'Available'),
('Gunasekar', '12345', 'General Doctor', 'skype:live:.cid.e203a8627ba0f0ea?call', '9790766216', 'nitesh12126@gmail.com', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `ngodetails`
--

CREATE TABLE `ngodetails` (
  `orgname` varchar(30) NOT NULL,
  `email` varchar(20) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ngodetails`
--

INSERT INTO `ngodetails` (`orgname`, `email`, `mobile`, `password`) VALUES
('Nitesh', 'nitesh12126@gmail.co', '9790766216', '12345'),
('Naveen_Org', 'nitesh12126@gmail.co', '9790766216', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE `pharmacy` (
  `name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`name`, `password`) VALUES
('medplus', '12345'),
('apollo', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `productdb`
--

CREATE TABLE `productdb` (
  `id` int(11) NOT NULL,
  `product_name` varchar(25) NOT NULL,
  `product_price` float DEFAULT NULL,
  `product_image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `purchasedetails`
--

CREATE TABLE `purchasedetails` (
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(30) NOT NULL,
  `state` varchar(20) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `purchaseid` varchar(20) NOT NULL,
  `items` varchar(20) NOT NULL,
  `code` varchar(20) NOT NULL,
  `amount` float NOT NULL,
  `qty` int(20) NOT NULL,
  `totalamt` float NOT NULL,
  `purdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `purchasedetails`
--

INSERT INTO `purchasedetails` (`name`, `email`, `phone`, `address`, `state`, `pincode`, `purchaseid`, `items`, `code`, `amount`, `qty`, `totalamt`, `purdate`) VALUES
('Nitesh', 'nitesh12126@gmail.com', '9790766216', 'No 3/189, KKD Nagar', 'tamil nadu', '600118', '38', 'Dolo-650', '3DcAM01', 0.8, 1, 0.8, '2021-04-03 23:11:25'),
('Naveen', 'nitesh12126@gmail.com', '9790766216', 'No 3/189, KKD Nagar', 'tamil nadu', '600118', '39', 'Crocin-650', 'USB02', 0.8, 1, 0.8, '2021-04-04 00:00:21'),
('Nitesh', 'nitesh12126@gmail.com', '9790766216', 'No 3/189, KKD Nagar', 'tamil nadu', '600118', '40', 'Athernal', '840tjpuf1c', 2, 1, 2, '2021-04-04 15:15:42'),
('Nitesh', 'nitesh12126@gmail.com', '9790766216', 'No 3/189, KKD Nagar', 'tamil nadu', '600118', '41', 'Dolo-650', '3DcAM01', 0.8, 10, 8.8, '2021-04-05 14:17:41'),
('Nitesh', 'nitesh12126@gmail.com', '9790766216', 'No 3/189, KKD Nagar', 'tamil nadu', '600118', '41', 'Crocin-650', 'USB02', 0.8, 1, 8.8, '2021-04-05 14:17:49'),
('Nitesh', 'nitesh12126@gmail.com', '9790766216', 'No 3/189, KKD Nagar', 'tamil nadu', '600118', '42', 'Dolo-650', '3DcAM01', 0.8, 5, 0, '2021-04-05 14:19:48');

-- --------------------------------------------------------

--
-- Table structure for table `purchasenumber`
--

CREATE TABLE `purchasenumber` (
  `punum` varchar(20) NOT NULL,
  `cond` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `purchasenumber`
--

INSERT INTO `purchasenumber` (`punum`, `cond`) VALUES
('43', '1');

-- --------------------------------------------------------

--
-- Table structure for table `sellmedicine`
--

CREATE TABLE `sellmedicine` (
  `medname` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `expirydate` varchar(12) NOT NULL,
  `quantity` int(4) NOT NULL,
  `pickaddress` varchar(35) NOT NULL,
  `medimage` blob NOT NULL,
  `brand` varchar(20) NOT NULL,
  `purchasebill` blob NOT NULL,
  `referenceno` int(10) NOT NULL,
  `verified` int(2) NOT NULL,
  `pharmacyvalidate` int(2) NOT NULL,
  `amount` float NOT NULL,
  `comment` varchar(200) NOT NULL,
  `added` int(2) NOT NULL,
  `selldate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sellmedicine`
--

INSERT INTO `sellmedicine` (`medname`, `email`, `phone`, `expirydate`, `quantity`, `pickaddress`, `medimage`, `brand`, `purchasebill`, `referenceno`, `verified`, `pharmacyvalidate`, `amount`, `comment`, `added`, `selldate`) VALUES
('Athernal', 'nitesh12126@gmail.com', '9790766216', '01/04/2024', 10, 'No 3/189, KKD Nagar', 0x636f6c6c6567652069642e6a706567, 'cipla', 0x50617373706f72742073697a65207069632e6a706567, 1235, 1, 1, 100, '', 0, '2021-04-04 15:11:15'),
('Gababin', 'nitesh12126@gmail.com', '9790766216', '01/04/2024', 10, 'No 3/189, KKD Nagar', 0x636f6c6c6567652069642e6a706567, 'cipla', 0x50617373706f72742073697a65207069632e6a706567, 2630, 1, 1, 100, 'qty=9', 0, '2021-04-05 14:13:41');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `medicine` varchar(20) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `qty` int(5) NOT NULL,
  `image` blob NOT NULL,
  `cost` float NOT NULL,
  `ngocost` float NOT NULL,
  `code` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`medicine`, `brand`, `qty`, `image`, `cost`, `ngocost`, `code`) VALUES
('gababin', 'cipla', 7, 0x30, 0.7, 0, 2667),
('dolo', 'cipla', 27, 0x30, 0.45, 0, 9999);

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `qty` int(10) NOT NULL,
  `price` double(10,2) NOT NULL,
  `ngocost` int(2) NOT NULL,
  `description` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`
--

INSERT INTO `tblproduct` (`id`, `name`, `code`, `image`, `qty`, `price`, `ngocost`, `description`) VALUES
(1, 'Dolo-650', '3DcAM01', 'product-images/dolo-650.jpg', 14, 0.80, 0, 'Dolo 650 Tablet is also used to reduce a high temperature (fever). It works by blocking the release of certain chemical messengers that cause fever. It may be prescribed alone or in combination with another medicine. You should take it regularly as advised by your doctor.'),
(2, 'Crocin-650', 'USB02', 'product-images/crocin-650.jpg', 38, 0.80, 0, ''),
(3, 'Dulcolax-5mg', 'dul03', 'product-images/dulcolax-5mg.jpg', 50, 0.20, 0, ''),
(4, 'Becosules', 'bes45', 'product-images/becosules.jpg', 50, 0.70, 0, ''),
(5, 'Phensedyl LM', 'phen34', 'product-images/phensedyl-lm.jpg', 50, 3.00, 0, ''),
(6, 'Foracort', 'for674', 'product-images/foracort-400mg.jpg', 50, 4.00, 0, ''),
(7, 'Pan-40mg', 'pan40', 'product-images/pan-40mg.jpg', 50, 1.00, 0, ''),
(8, 'Monocef-200mg', 'mono34', 'product-images/monocef-200mg.jpg', 50, 3.00, 0, ''),
(9, 'Glycomet-500mg', 'gly50', 'product-images/glycomet-500mg.png', 50, 2.00, 0, ''),
(14, 'Athernal', '840tjpuf1c', 'product-images/no-image.png', 9, 2.00, 0, ''),
(15, 'Gababin', '8k1sz7jhtr', 'product-images/no-image.png', 9, 2.00, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE `temp` (
  `value` int(20) NOT NULL,
  `code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `desg` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `email`, `mobile`, `pass`, `desg`) VALUES
('Nitesh', 'nitesh@gmail.com', '9790766216', '123456', 'admin'),
('nitesh', 'vnitesh12126@gmail.com', '9790766216', '12345', 'users');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `productdb`
--
ALTER TABLE `productdb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sellmedicine`
--
ALTER TABLE `sellmedicine`
  ADD UNIQUE KEY `referenceno` (`referenceno`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD UNIQUE KEY `medid` (`code`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_code` (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `productdb`
--
ALTER TABLE `productdb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblproduct`
--
ALTER TABLE `tblproduct`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
