<?php  
 require('db_connection.php');

if (isset($_POST['username']) and isset($_POST['userpassword'])){
	
// Assigning POST values to variables.
$username = $_POST['username'];
$password = $_POST['userpassword'];
$count=0;

// CHECK FOR THE RECORD FROM TABLE
$query = "SELECT * FROM `ngodetails` WHERE orgname='$username' and password='$password' ";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
$count = mysqli_num_rows($result);

if ($count == 1){

header("location: ngohome.html");
}

else{
	
header("location: invalidpwdngo.html");
}
}
?>
