<?php
session_start();
require('db_connection.php');
$value = $_SESSION['docname'];
$query="UPDATE `doctor` SET `availability`= 'Not Available' WHERE docname='$value';";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
echo "<script>alert('Status: Not Available');
			window.location.href='doctorhome.php';
			</script>";
?>