<?php  

session_start();
 require('db_connection.php');

if (isset($_POST['username']) and isset($_POST['userpassword'])){
	
// Assigning POST values to variables.
$username = $_POST['username'];
$password = $_POST['userpassword'];
$count=0;

// CHECK FOR THE RECORD FROM TABLE
$query = "SELECT * FROM `users` WHERE username='$username' and pass='$password' and desg='users'";
$query1 = "SELECT * FROM `users` WHERE username='$username' and pass='$password' and desg='admin'";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
$count = mysqli_num_rows($result);
$count1 = mysqli_num_rows($result1);
$countname = mysqli_num_rows($result);
$pass = mysqli_num_rows($result);


if ($count == 1){

//echo "Login Credentials verified";
//$_SESSION['name'] = $username;
header("location: home.php");
}
else if($count1 == 1){
	
$_SESSION['name'] = $username;
header("location: admin.php");
}
else{
	
header("location: invalidpwd.html");
//echo "Invalid Login Credentials";
}
}
?>
