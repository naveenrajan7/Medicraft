<?php
if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location:../index.html');
    exit;
}
?>

<!--<?php
    session_start();
?>-->

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!--========== BOX ICONS ==========-->
        <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
        <script src="https://kit.fontawesome.com/b8991598b2.js"></script>
        <script src="https://unpkg.com/boxicons@latest/dist/boxicons.js"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
        <script src="app.js"></script>
        <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

        <!--======================Offline Code=========================-->
        <script src="offline.min.js"></script>
        <link rel="stylesheet" type="text/css" href="offline-theme-default.css">
        <link rel="stylesheet" href="offline-language-english.min.css" />

        <!--<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">-->

        <!--========== CSS ==========-->
        <link rel="stylesheet" href="homestyle.css">
        <link rel="stylesheet" href="cartstyle.css">

        <!--===================Preventing Back button==============================-->
        <script type="text/javascript">
            function preventBack() { window.history.forward(); }
            setTimeout("preventBack()", 0);
            window.onunload = function () { null };
        </script>

        <title>Medicraft</title>
    </head>
    <body>

        <!--===========Offline script code======================-->
        <script type="text/javascript">
            Offline.options = {
                // to check the connection status immediatly on page load.
                checkOnLoad: false,

                // to monitor AJAX requests to check connection.
                interceptRequests: true,

                // to automatically retest periodically when the connection is down (set to false to disable).
                reconnect: {
                    // delay time in seconds to wait before rechecking.
                    initialDelay: 3,

                    // wait time in seconds between retries.
                    delay: 5
                },

                // to store and attempt to remake requests which failed while the connection was down.
                requests: true
            };
        </script>

        <script>
            const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })

                Toast.fire({
                    icon: 'success',
                    title: 'Signed in successfully'
                })
        </script>

        <script>
            function itemCart() {
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })

                Toast.fire({
                    icon: 'success',
                    title: 'Item added to Cart'
                })
            }
        </script>

        <script>
            function noCart() {
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })

                Toast.fire({
                    icon: 'warning',
                    title: 'No items in Cart'
                })
            }
        </script>

        <script>
            function signoutUser() {
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'center',
                    showConfirmButton: true,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })

                Toast.fire({
                    icon: 'warning',
                    iconColor: 'red',
                    title: 'Are you sure to signOut?',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, confirm',
                    cancelButtonText: 'No, cancel',
                    cancelButtonColor: '#d33',
                    confirmButtonColor: '#069c54',
                    toast: true,
                }).then((result) => {
                    if (result.isConfirmed) {
                        console.log(result);
                        firebase.auth().signOut().then(function () {
                            window.location = "login.html";
                        }, function (error) {
                            console.error('Sign Out Error', error);
                        });

                    }
                })
            }
        </script>

        <script>
            function emptyCart() {
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })

                Toast.fire({
                    icon: 'warning',
                    title: 'One items has removed from cart!'
                })
            }
        </script>




        <!--========== SCROLL TOP ==========-->
        <a href="#" class="scrolltop" id="scroll-top">
            <i class='bx bx-chevron-up scrolltop__icon'></i>
        </a>

        <!--========== HEADER ==========-->
        <header class="l-header" id="header">
            <nav class="nav bd-container">
                <a href="#" class="nav__logo">Medicraft</a>

                <div class="nav__menu" id="nav-menu">
                    <ul class="nav__list">
                        <li class="nav__item"><a href="#home" class="nav__link active-link">Home</a></li>
                        <li class="nav__item"><a href="#services" class="nav__link">Services</a></li>
                       
                        <li class="nav__item"><a href="#contact" class="nav__link">Contact us</a></li>
                        <li class="nav__item"><a href="emergency.html" class="nav__link">Tips</a></li>
                        <li class="nav__item"><a href="doctor.php" class="nav__link">Consultant</a></li>
                        <li class="nav__item"><a id="logout" class="nav__link" onclick="signoutUser();" style="cursor: pointer;">SignOut</a></li>

                        <!--<?php
                             echo "welcome".$_SESSION['name'];
                        ?>-->


                        <li><i class='bx bx-moon change-theme' id="theme-button"></i></li>
                        <div class="cart-btn">
                        </div>
                    </ul>
                </div>


                <div class="nav__toggle" id="nav-toggle">
                    <i class='bx bx-menu'></i>
                </div>
            </nav>
        </header>

         

        <main class="l-main">
            <!--========== HOME ==========-->
            <section class="home" id="home">
                <div class="home__container bd-container bd-grid">
                    <div class="home__data">
                        <h1 class="home__title">Medicraft</h1>
                        <h2 class="home__subtitle">You can buy (or) <br> sell the medicine.</h2>
                        <a href="sell.html" class="buttons">Sell Medicines</a>
						<a href="cart.php" class="buttons">Buy Medicines</a>
						<a href="sellstatus.php" class="buttons">Check Status</a>
                    </div>
    
                    <img src="img/tablet.svg" alt="" class="home__img">
                </div>
            </section>
            
            <!--========== ABOUT ==========-->
            <section class="about section bd-container" id="about">
                <div class="about__container  bd-grid">
                    <div class="about__data">
                        <span class="section-subtitle about__initial">About us</span>
                        <h2 class="section-title about__initial">We provide the best <br> medicines</h2>
                        <p class="about__description">We provide the best medicines in the entire city, with excellent customer service, the best quality and at the best price, visit us.</p>
                        <a href="team.html" class="buttons">Explore history</a>
                    </div>

                    <img src="img/team.svg" alt="" class="about__img">
                </div>
            </section>

            <!--========== SERVICES ==========-->
            <section class="services section bd-container" id="services">
                <span class="section-subtitle">Offering</span>
                <h2 class="section-title">Our amazing services</h2>

                <div class="services__container  bd-grid">
                    <div class="services__content">
                        <svg class="services__img" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart" viewBox="0 0 16 16">
                            <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
                        </svg>
                       
                        <h3 class="services__title">Buy Medicines</h3>
                        <p class="services__description">You can also buy all medicines. We offer amazing features in our websites.</p>
                    </div>

                    <div class="services__content">
                        <svg class="services__img" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-shop" viewBox="0 0 16 16">
                            <path d="M2.97 1.35A1 1 0 0 1 3.73 1h8.54a1 1 0 0 1 .76.35l2.609 3.044A1.5 1.5 0 0 1 16 5.37v.255a2.375 2.375 0 0 1-4.25 1.458A2.371 2.371 0 0 1 9.875 8 2.37 2.37 0 0 1 8 7.083 2.37 2.37 0 0 1 6.125 8a2.37 2.37 0 0 1-1.875-.917A2.375 2.375 0 0 1 0 5.625V5.37a1.5 1.5 0 0 1 .361-.976l2.61-3.045zm1.78 4.275a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 1 0 2.75 0V5.37a.5.5 0 0 0-.12-.325L12.27 2H3.73L1.12 5.045A.5.5 0 0 0 1 5.37v.255a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0zM1.5 8.5A.5.5 0 0 1 2 9v6h1v-5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v5h6V9a.5.5 0 0 1 1 0v6h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1V9a.5.5 0 0 1 .5-.5zM4 15h3v-5H4v5zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3zm3 0h-2v3h2v-3z"/>
                        </svg>
                      
                        <h3 class="services__title">Sell Medicines</h3>
                        <p class="services__description">You can also sell all medicines. We offer amazing features in our websites.</p>
                    </div>

                    <div class="services__content">
                        <svg class="services__img" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0)">
                            <path d="M19.1978 49.6016C17.4308 49.6016 15.9981 51.0342 15.9981 52.8012C15.9981 54.5682 17.4308 
                            56.0008 19.1978 56.0008C20.9648 56.0008 22.3974 54.5682 22.3974 52.8012C22.3974 51.0342 20.9648 
                            49.6016 19.1978 49.6016ZM19.1978 53.8677C18.6088 53.8677 18.1312 53.3902 18.1312 52.8012C18.1312 
                            52.2122 18.6088 51.7347 19.1978 51.7347C19.7868 51.7347 20.2643 52.2122 20.2643 52.8012C20.2643 
                            53.3902 19.7868 53.8677 19.1978 53.8677Z"/>
                            <path d="M50.1275 49.6016C48.3605 49.6016 46.9279 51.0342 46.9279 52.8012C46.9279 54.5682 48.3605 
                            56.0008 50.1275 56.0008C51.8945 56.0008 53.3271 54.5682 53.3271 52.8012C53.3271 51.0342 51.8945 
                            49.6016 50.1275 49.6016ZM50.1275 53.8677C49.5385 53.8677 49.0609 53.3902 49.0609 52.8012C49.0609 
                            52.2122 49.5385 51.7347 50.1275 51.7347C50.7165 51.7347 51.194 52.2122 51.194 52.8012C51.194 
                            53.3902 50.7165 53.8677 50.1275 53.8677Z"/>
                            <path d="M3.19962 21.8715H5.3327V24.0045H3.19962V21.8715Z"/>
                            <path d="M0 26.1377H2.13308V28.2708H0V26.1377Z"/>
                            <path d="M52.2606 11.2061H58.6598V13.3391H52.2606V11.2061Z"/>
                            <path d="M47.9944 11.2061H50.1275V13.3391H47.9944V11.2061Z"/>
                            <path d="M34.1294 4.80676H44.7948V6.93985H34.1294V4.80676Z"/>
                            <path d="M29.8632 4.80676H31.9963V6.93985H29.8632V4.80676Z"/>
                            <path d="M63.9925 59.2005V57.0674H54.8842C55.7935 56.0607 56.3575 54.7906 56.495 53.4412L63.4593 
                            49.461C63.5087 49.4266 63.5556 49.3886 63.5988 49.3469C63.6363 49.3214 63.6723 49.2928 63.7056 
                            49.2626C63.7858 49.1777 63.8514 49.0798 63.8998 48.9735C63.905 48.9636 63.9123 48.9574 63.917 
                            48.948C63.9655 48.8272 63.9915 48.6986 63.9936 48.5684C63.9936 48.5564 63.9998 48.547 63.9998 
                            48.535V38.9362C63.9951 38.9049 63.9889 38.8742 63.9806 38.8435C63.9821 38.8159 63.9821 38.7877 
                            63.9806 38.7601L61.8475 25.9616C61.8428 25.946 61.8371 25.9299 61.8308 25.9148C61.8308 25.9033 
                            61.8308 25.8903 61.8308 25.8788L60.7643 21.6127C60.645 21.1367 60.2169 20.8034 59.7264 20.8049H46.7893C46.6446 
                            20.2852 46.3696 19.8103 45.9905 19.4259L38.708 12.1435C38.1096 11.5414 37.2951 11.204 36.4457 
                            11.2061H10.6654C10.0764 11.2061 9.59888 11.6836 9.59888 12.2726V16.5388H0V18.6719H9.59888V21.8715H7.4658V24.0046H9.59888V26.1377H4.26617V28.2707H9.59888V37.8696C9.00989 
                            37.8696 8.53234 38.3472 8.53234 38.9362V48.535C8.53234 48.5574 8.54432 48.5767 8.54536 48.6001C8.55161 
                            48.6965 8.57088 48.7918 8.60264 48.8829C8.61254 48.9168 8.62451 48.9501 8.63805 48.9829C8.68805 49.0949 
                            8.75679 49.1969 8.84168 49.285L12.8178 53.2611C12.9198 54.6749 13.4911 56.0149 14.441 57.0674H0V59.2005H63.9925ZM44.1016 50.6681H25.2236C25.0929 
                            50.2984 24.9278 49.9411 24.731 49.6016H44.5943C44.3974 49.9411 44.2323 50.2984 44.1016 50.6681ZM25.597 
                            52.8012H43.7282C43.7288 54.3776 44.3141 55.8977 45.3708 57.0674H23.9545C25.0111 55.8977 25.5965 54.3776 
                            25.597 52.8012ZM45.8613 52.8012C45.8613 50.4452 47.7715 48.535 50.1275 48.535C52.4835 48.535 54.3937 
                            50.4452 54.3937 52.8012C54.3937 55.1572 52.4835 57.0674 50.1275 57.0674C47.7715 57.0674 45.8613 55.1572 45.8613 
                            52.8012ZM56.2898 51.0946C56.145 50.5723 55.9336 50.0703 55.6607 49.6016H58.9093L56.2898 51.0946ZM61.6662 
                            37.8696H51.194V27.2042H59.8894L61.6662 37.8696ZM59.4269 25.0711H50.1275C49.5385 25.0711 49.0609 25.5487 
                            49.0609 26.1377V38.9362C49.0609 39.5252 49.5385 40.0027 50.1275 40.0027H61.8595V42.1358H58.6598V44.2689H61.8595V47.4685H53.6578C51.519 
                            46.0463 48.736 46.0463 46.5972 47.4685H22.7281C20.5893 46.0463 17.8063 46.0463 15.6674 
                            47.4685H10.6654V43.2023H14.9316V41.0692H10.6654V40.0027H45.8613C46.4503 40.0027 46.9279 
                            39.5252 46.9279 38.9362V22.938H58.8937L59.4269 25.0711ZM11.732 28.2707H20.2643V26.1377H11.732V24.0046H21.3308V21.8715H11.732V18.6719H17.0647V16.5388H11.732V13.3391H36.4457C36.7285 
                            13.3402 36.9993 13.4527 37.1998 13.6516L44.4823 20.9341C44.6828 21.1341 44.7948 21.4059 44.7948 21.6892V37.8696H11.732V28.2707ZM13.6646 
                            49.6016C13.4766 49.9255 13.3177 50.2661 13.1901 50.6181L12.1736 49.6016H13.6646ZM14.9316 
                            52.8012C14.9316 50.4452 16.8418 48.535 19.1978 48.535C21.5537 48.535 23.4639 50.4452 23.4639 
                            52.8012C23.4639 55.1572 21.5537 57.0674 19.1978 57.0674C16.8418 57.0674 14.9316 55.1572 14.9316 52.8012Z"/>
                                </g>
                                <defs>
                                <clipPath id="clip0">
                                <rect width="64" height="64" fill="white"/>
                                </clipPath>
                                </defs>
                        </svg>
                        <h3 class="services__title">Delivery</h3>
                        <p class="services__description">We offer our clients excellent quality services with the best and safe delivery in the city.</p>
                    </div>
                </div>
            </section>
			
            <section class="services section bd-container" id="services">
                <span class="section-subtitle">Safe Delivery</span>
                <h2 class="section-title">4 Steps Safety Assured</h2>
                <div class="services__container  bd-grid">
                    <div class="services__content">
                        <img src="img/tempature.png"  width="150" height="150"/>
                    </div>
                    <div class="services__content">
                        <img src="img/secure.png" width="150" height="150"/>
                    </div>
                    <div class="services__content">
                        <img src="img/santized.png" width="150" height="150"/>
                    </div>
                    <div class="services__content">
                        <img src="img/no.png" width="150" height="150"/>
                    </div>
                </div>
            </section>
           

            <!--===== APP =======-->
            <section class="app section bd-container">
                <div class="app__container bd-grid">
                    <div class="app__data">
                        <span class="section-subtitle app__initial">Mobile App</span>
                        <h2 class="section-title app__initial">Coming Soon!!</h2>
                        <p class="app__description">Find our application and download it, you can buy medicines, and sell medicines, see your deliveries on the way and much more.</p>
                        <div class="app__stores">
                            <!--<a href="#"><img src="assets/img/app1.png" alt="" class="app__store"></a>
                            <a href="#"><img src="assets/img/app2.png" alt="" class="app__store"></a>-->
                        </div>
                    </div>

                    <img src="img/mobile.svg" alt="" class="app__img">
                </div>
            </section>

            <!--========== CONTACT US ==========-->
            <section class="contact section bd-container" id="contact">
                <div class="contact__container bd-grid">
                    <div class="contact__data">
                        <span class="section-subtitle contact__initial">Let's talk</span>
                        <h2 class="section-title contact__initial">Contact us</h2>
                        <p class="contact__description">If you want have any queries, contact us and we will attend you quickly, with our 24/7 chat service.</p>
                    </div>

                    <div class="contact__button">
                        <a href="contact.html" class="buttons">Contact us now</a>
                    </div>
                </div>
            </section>
        </main>

        <!--========== FOOTER ==========-->
        <footer class="footer section bd-container">
            <div class="footer__container bd-grid">
                <div class="footer__content">
                    <a href="#" class="footer__logo">Medicraft</a>
                    <span class="footer__description">Buy (or) sell Medicines</span>
                    <div>
                        <a href="#" class="footer__social"><i class='bx bxl-facebook'></i></a>
                        <a href="#" class="footer__social"><i class='bx bxl-instagram'></i></a>
                        <a href="#" class="footer__social"><i class='bx bxl-twitter'></i></a>
                    </div>
                </div>

                <div class="footer__content">
                    <h3 class="footer__title">Services</h3>
                    <ul>
                        <li><a href="cart.php" class="footer__link">Buy Medicines</a></li>
                        <li><a href="sell.html" class="footer__link">Sell Medicines</a></li>
                        <li><a href="emergency.html" class="footer__link">Emergency Tips</a></li>
                        <li><a href="doctor.php" class="footer__link">Doctor Consultant</a></li>
                    </ul>
                </div>

                <div class="footer__content">
                    <h3 class="footer__title">Information</h3>
                    <ul>
                        <li><a href="#" class="footer__link">Event</a></li>
                        <li><a href="contact.html" class="footer__link">Contact us</a></li>
                        <li><a href="#" class="footer__link">Privacy policy</a></li>
                        <li><a href="#" class="footer__link">Terms of services</a></li>
                    </ul>
                </div>

                <div class="footer__content">
                    <h3 class="footer__title">Address</h3>
                    <ul>
                        <li>Chennai</li>
                        <li>Tamilnadu</li>
                        <li>123 - 456 - 789</li>
                        <li>medicraft@gmail.com</li>
                    </ul>
                </div>
            </div>

            <p class="footer__copy">&#169; 2021 Medicraft. All right reserved</p>
        </footer>

        <!--========== CART ==========-->
        <div class="cart-overlay">
            <div class="cart">
                <span class="close-cart">
                    <i class="fas fa-window-close" style="margin-top: 60px;"></i>
                </span>
                <h2>Your Cart Items</h2>
                <div class="cart-content">
                   
                </div>
                <div class="cart-footer">
                    <h3>Your total : <i class="fas fa-rupee-sign"></i> <span class="cart-total">0</span></h3>
                    <button class="clear-cart banner-btn" onclick="noCart();">Clear Cart</button>
                    <a href="billaddress.html">
                        <button class="clear-cart banner-btn">Checkout</button>
                    </a>
                    
                </div>
            </div>
        </div>

        <!--========== SCROLL REVEAL ==========-->
        <script src="https://unpkg.com/scrollreveal"></script>

        <!--========== MAIN JS ==========-->
        <script src="main.js"></script>

        <!-- The core Firebase JS SDK is always required and must be listed first -->
        <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-app.js"></script>
        
        <!-- TODO: Add SDKs for Firebase products that you want to use
                         https://firebase.google.com/docs/web/setup#available-libraries -->
        <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-analytics.js"></script>
        
        <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-auth.js"></script>
        <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-firestore.js"></script>
        
        <script>
            // Your web app's Firebase configuration
            // For Firebase JS SDK v7.20.0 and later, measurementId is optional
            var firebaseConfig = {
                apiKey: "AIzaSyCXbYC7VXC412C_RNwzK7m69g30PERbF2k",
                authDomain: "medicraft-24732.firebaseapp.com",
                projectId: "medicraft-24732",
                storageBucket: "medicraft-24732.appspot.com",
                messagingSenderId: "969667024588",
                appId: "1:969667024588:web:33dee27c9766162f9a5469",
                measurementId: "G-NVEYWSRK4X"
            };
            // Initialize Firebase
            firebase.initializeApp(firebaseConfig);
            firebase.analytics();

        </script>

    </body>
</html>