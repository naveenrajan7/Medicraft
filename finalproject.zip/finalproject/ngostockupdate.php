<?php
require('db_connection.php');
$code=$_POST['code'];
$qty=$_POST['qty'];
$query1="select qty from tblproduct where code='$code' ";
				$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
				$row= mysqli_fetch_assoc($result1);
				if($row['qty']>0)
				{
				$newqty=$row['qty']+$qty;
							
							$query2="update tblproduct set qty='$newqty' where code='$code'";
							$result2 = mysqli_query($connection, $query2) or die(mysqli_error($connection));
							$query4="select punum from purchasenumber where cond=1";
							$result4 = mysqli_query($connection, $query4) or die(mysqli_error($connection));
							$row1= mysqli_fetch_array($result4);
							$puno=$row1['punum'];
							
						
							$query3="DELETE FROM `purchasedetails` WHERE purchaseid='$puno' and code='$code'";
							$result3 = mysqli_query($connection, $query3) or die(mysqli_error($connection));
							//echo " success";
				header("location: ngocart.php?action=remove&code=$code");}
				else{
					header("location: ngocart.php?action=remove&code=$code");
					echo "item is not available";}
?>

