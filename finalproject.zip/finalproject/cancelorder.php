<?php
require('db_connection.php');
$query="select punum from purchasenumber";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
							$row= mysqli_fetch_assoc($result);
							$puno=$row['punum'];
							$pid=(int)$puno-1;
							
							$query1="SELECT DISTINCT code FROM purchasedetails where purchaseid='$pid'";
								$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
								
							while($row1 = mysqli_fetch_array($result1))
							{
								$code=$row1['code'];
								
								$query2="SELECT qty FROM tblproduct where code='$code'";
								$result2 = mysqli_query($connection, $query2) or die(mysqli_error($connection));
								while($row2 = mysqli_fetch_array($result2))
									
									{
										//echo $row2['qty'];
										
										$query3="SELECT SUM(qty)  FROM purchasedetails where code='$code' and purchaseid='$pid' ";
								$result3 = mysqli_query($connection, $query3) or die(mysqli_error($connection));
								
							while($row3 = mysqli_fetch_array($result3))
							{//echo "<br>";
								//echo $row3['COUNT(DISTINCT items)'];
								 //echo $row3['SUM(qty)']; 
								 
								 $qty=(int)$row2['qty']+(int)$row3['SUM(qty)'];
								 //echo $qty;
								 
								 $query4="update tblproduct set qty='$qty' where code='$code'";
							$result4 = mysqli_query($connection, $query4) or die(mysqli_error($connection));
							
							
								
								
							
							}
										
										
									}
							}
							$query5="DELETE FROM `purchasedetails` WHERE purchaseid='$pid'";
						$result5 = mysqli_query($connection, $query5) or die(mysqli_error($connection));
						
						$query6="DELETE FROM `temp`";
						$result6 = mysqli_query($connection, $query6) or die(mysqli_error($connection));
							
							echo "<script>
								alert('Order is cancelled');
									window.location.href='index.html';
</script>";
							?>