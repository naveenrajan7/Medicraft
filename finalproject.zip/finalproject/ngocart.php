<?php
if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location:../index.html');
    exit;
}
?>

<?php
session_start();
require_once("dbcontroller.php");
require('db_connection.php');
$db_handle = new DBController();
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "add":
		if(!empty($_POST["quantity"])) {
			$productByCode = $db_handle->runQuery("SELECT * FROM tblproduct WHERE code='" . $_GET["code"] . "'");
			$itemArray = array($productByCode[0]["code"]=>array('name'=>$productByCode[0]["name"], 'code'=>$productByCode[0]["code"], 'quantity'=>$_POST["quantity"], 'price'=>$productByCode[0]["ngocost"], 'image'=>$productByCode[0]["image"]));
			$code=$productByCode[0]["code"];
			$qty=$_POST['quantity'];
			
			
				$query1="select qty,name,price from tblproduct where code='$code' ";
				$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
					//$count = mysqli_num_rows($result1);
					$row= mysqli_fetch_assoc($result1);
					$temp=$row['qty'];
				$query6="INSERT INTO temp VALUES ('$temp','$code')";
							$result6 = mysqli_query($connection, $query6) or die(mysqli_error($connection));
					$namee=$row['name'];
					$pricee=$row['price'];
					//if($count==1)
					//{
						if((int)$qty<=$row['qty'] and $row['qty']!=0)
							
						{
							date_default_timezone_set('Asia/Kolkata');
							$date = date('Y-m-d H:i:s', time());


							
							
							$newqty=$row['qty']-(int)$qty;
							//$ppid=constant("purchaseid");
	
							$query2="update tblproduct set qty='$newqty'where code='$code'";
							$result2 = mysqli_query($connection, $query2) or die(mysqli_error($connection));
							
							$query4="select punum from purchasenumber where cond=1";
							$result4 = mysqli_query($connection, $query4) or die(mysqli_error($connection));
							$row1= mysqli_fetch_array($result4);
							$puno=$row1['punum'];
							
							$query3="insert into purchasedetails values(0,0,0,0,0,0,'$puno','$namee','$code','$pricee','$qty',0,'$date')";
							$result3 = mysqli_query($connection, $query3) or die(mysqli_error($connection));
							//echo "success";
							
							
						}
						else 
						{
							//$upd=$row['qty'];
							//header("location: outofstock.html");
							
							
							$query8="select value from temp where code='$code'";
							$result8 = mysqli_query($connection, $query8) or die(mysqli_error($connection));
							$row8= mysqli_fetch_array($result8);
							$upd=$row8['value'];
							//echo "Available value is :".$upd;
							
							$query5="update tblproduct set qty='$upd' where code='$code'";
							$result5 = mysqli_query($connection, $query5) or die(mysqli_error($connection));
							
							$query7="DELETE FROM temp where code='$code'";
							$result7 = mysqli_query($connection, $query7) or die(mysqli_error($connection));
							
						
							//header("location: cart.php?action=remove&code=$code[$i]");
							echo "<script>
								alert('Out of stock');
									window.location.href='ngocart.php?action=remove&code=$code';
								</script>";
							
						}
			
			
			
			
			
			if(!empty($_SESSION["cart_item"])) {
				
				
				if(in_array($productByCode[0]["code"],array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {								
							if($productByCode[0]["code"] == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
	case "remove":
					
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					if($_GET["code"] == $k)
					unset($_SESSION["cart_item"][$k]);
									
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]);
			}
			

		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
		header("location: ngobill.html");
	break;	
			 
}
}
?>
<HTML>

<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!--========== BOX ICONS ==========-->
        <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
        <script src="https://kit.fontawesome.com/b8991598b2.js"></script>
        <script src="https://unpkg.com/boxicons@latest/dist/boxicons.js"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
        <script src="app.js"></script>
		<link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

        <!--======================Offline Code=========================-->
        <script src="offline.min.js"></script>
        <link rel="stylesheet" type="text/css" href="offline-theme-default.css">
        <link rel="stylesheet" href="offline-language-english.min.css" />

        <!--<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">-->

        <!--========== CSS ==========-->
        <link rel="stylesheet" href="homestyle.css">
        <link rel="stylesheet" href="cartstyle.css">
		<!--<link href="style1.css" type="text/css" rel="stylesheet" />-->

        <title>Medicraft</title>
    </head>
	
	<style>
		.btnAddAction {
			font-family: "Poppins", sans-serif;
  padding: 5px 10px;
  margin-left: 5px;
  background-color: #069c54;
  border: #e0e0e0 1px solid;
  color: white;
  float: center;
  text-decoration: none;
  border-radius: 30px;
  cursor: pointer;
  outline: none;
}

		.product-quantity {
			font-family: "Poppins", sans-serif;
  padding: 5px 10px;
  border-radius: 30px;
  border: #e0e0e0 1px solid;
  outline: none;
}

		.txt-heading {
  color: #211a1a;
  border-bottom: 1px solid #e0e0e0;
  overflow: auto;
}

		.tbl-cart {
  font-size: 0.9em;
}

		#shopping-cart {
  margin: 40px;
}

		.tbl-cart {
  font-size: 0.9em;
}

		#shopping-cart table {
  width: 100%;
  background-color: #f0f0f0;
}

#shopping-cart table td {
  background-color: #ffffff;
}

		#product-grid .txt-heading {
  margin-bottom: 18px;
}

		.cart-item-image {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  border: #e0e0e0 1px solid;
  padding: 5px;
  vertical-align: middle;
  margin-right: 15px;
}

.menu__content:hover {
        z-index:1;
        transform: scale(1.07);
        box-shadow: 0 25px 40px rgba(rgb(94, 93, 93), rgb(44, 44, 44), rgb(75, 75, 75), alpha);
    }

	</style>

<BODY>

	<!--===========Offline script code======================-->
        <script type="text/javascript">
            Offline.options = {
                // to check the connection status immediatly on page load.
                checkOnLoad: false,

                // to monitor AJAX requests to check connection.
                interceptRequests: true,

                // to automatically retest periodically when the connection is down (set to false to disable).
                reconnect: {
                    // delay time in seconds to wait before rechecking.
                    initialDelay: 3,

                    // wait time in seconds between retries.
                    delay: 5
                },

                // to store and attempt to remake requests which failed while the connection was down.
                requests: true
            };
        </script>

		<script>
            function signoutUser() {
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'center',
                    showConfirmButton: true,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })

                Toast.fire({
                    icon: 'warning',
                    iconColor: 'red',
                    title: 'Are you sure to signOut?',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, confirm',
                    cancelButtonText: 'No, cancel',
                    cancelButtonColor: '#d33',
                    confirmButtonColor: '#069c54',
                    toast: true,
                }).then((result) => {
                    if (result.isConfirmed) {
                        console.log(result);
                        firebase.auth().signOut().then(function () {
                            window.location = "ngo.html";
                        }, function (error) {
                            console.error('Sign Out Error', error);
                        });

                    }
                })
            }
        </script>

		<!--========== SCROLL TOP ==========-->
        <a href="#" class="scrolltop" id="scroll-top">
            <i class='bx bx-chevron-up scrolltop__icon'></i>
        </a>

		<!--========== HEADER ==========-->
        <header class="l-header" id="header">
            <nav class="nav bd-container">
                <a href="ngohome.html" class="nav__logo">Medicraft</a>

                <div class="nav__menu" id="nav-menu">
                    <ul class="nav__list">
                        <li class="nav__item"><a href="#home" class="nav__link active-link">Home</a></li>
                        <li class="nav__item"><a href="#product-grid" class="nav__link">Medicines</a></li>
                        <li class="nav__item"><a href="ngoemergency.html" class="nav__link">Tips</a></li>
                        <li class="nav__item"><a href="doctor.html" class="nav__link">Consultant</a></li>
                        <li class="nav__item"><a id="logout" class="nav__link" href="login.html" style="cursor: pointer;">SignOut</a></li>
						<li class="nav__item"><a href="ngohome.html" class="nav__link">Back</a></li>
                        <li><i class='bx bx-moon change-theme' id="theme-button"></i></li>
                    </ul>
                </div>

                <div class="nav__toggle" id="nav-toggle">
                    <i class='bx bx-menu'></i>
                </div>
            </nav>
        </header>

		<main class="l-main">
            <!--========== HOME ==========-->
            <section class="home" id="home">
                <div class="home__container bd-container bd-grid">
                    <div class="home__data">
                        <h1 class="home__title">Medicraft</h1>
                        <h2 class="home__subtitle">You can buy <br> medicine from here.</h2>
                    </div>
    
                    <img src="img/cart.svg" alt="" class="home__img">
                </div>
            </section>
		

			<section class="menu section bd-container" id="menu">
                <div id="shopping-cart">
	<center>
		<div class="txt-heading" style="font-weight:bold;">Shopping Cart</div>
	</center>

	<!--<a id="btnEmpty" href="cart.php?action=empty">Empty Cart</a>-->
	<?php
	if(isset($_SESSION["cart_item"])){
		$total_quantity = 0;
		$total_price = 0;
	?>	
	<table class="tbl-cart" cellpadding="10" cellspacing="1">
	<tbody>
	<tr>
	<th style="text-align:left;">Name</th>
	<th style="text-align:left;">Code</th>
	<th style="text-align:right;" width="5%">Quantity</th>
	<th style="text-align:right;" width="10%">Available</th>
	<th style="text-align:right;" width="10%">Unit Price</th>
	<th style="text-align:right;" width="12%">Price</th>
	<th style="text-align:center;" width="7%">Remove</th>
	</tr>	
	<?php						
		foreach ($_SESSION["cart_item"] as $item){
			$item_price = $item["quantity"]*$item["price"];
			?>
			<form action="ngostockupdate.php" method="POST">
					<tr>
					<td><img src="<?php echo $item["image"]; ?>" class="cart-item-image" /><?php echo $item["name"]; ?></td>
					<td><?php echo $item["code"]; ?></td>
					<td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
					<?php
					$tempcode=$item["code"];
					$query9="select value from temp where code='$tempcode'";
								$result9 = mysqli_query($connection, $query9) or die(mysqli_error($connection));
								$row9= mysqli_fetch_array($result9);
								$upd1=$row9['value'];
								$upd2=$upd1-(int)$item["quantity"];
					
					
					?>
					
					<td  style="text-align:right;"><?php echo "Nos.".$upd2; ?></td>
					<td  style="text-align:right;"><?php echo "&#8377 ".$item["price"]; ?></td>
					<td  style="text-align:right;"><?php echo "&#8377 ". number_format($item_price,2); ?></td>
					<input type="hidden" value="<?php echo $item["quantity"]; ?>" name="qty">
					<input type="hidden" value="<?php echo $item["code"]; ?>" name="code">
					<td style="text-align:center;"><input type="submit" value="Delete" style="background-color: red; border: #e0e0e0 1px solid; color: white; padding: 5px 10px; margin-left: 5px; color: white; text-decoration: none; border-radius: 30px; cursor: pointer; outline: none; font-family: Poppins, sans-serif;"></td>
					</tr>
					</form>
					
					
					
					<?php
					$total_quantity += $item["quantity"];
					$total_price += ($item["price"]*$item["quantity"]);
		}
		?>
		<?php
			//echo $total_price;
			//echo $item["code"];
		?>
		<form action="ngopurchasedetails.php" method="POST">
			<input type="hidden" value="<?php echo $total_price; ?>" name="amt">
					
					
					
			<tr>
			<td colspan="2" align="right">Total:</td>
			<td align="right"><?php echo $total_quantity; ?></td>
			<td align="right" colspan="2"><strong><?php echo "&#8377 ".number_format($total_price, 2); ?></strong></td>
			<td></td>
			<td><input type="submit" value="checkout" style="background-color: #069c54; border: #e0e0e0 1px solid; color: white; padding: 5px 10px; margin-left: 5px; color: white; text-decoration: none; border-radius: 30px; cursor: pointer; outline: none; font-family: Poppins, sans-serif;"></td>
			</tr>
		</form>
		</tbody>
		</table>		
		<?php
		} else {
		?>
		<center>
			<div class="no-records" style="color: red;">Your Cart is Empty!!</div>
			<br>
			<img src="img/empty.svg" style="hight: 30%; width: 30%;"></img>
		</center>
		<?php 
			}
		?>
</div>

		<!--</section>-->

<div id="product-grid" class="menu section">
	<center>
	<div class="txt-heading" style="font-weight:bold;">Products</div>
	<div class="section-title">
                    <!--<input type="text" class="searchBar" id="searchBar" placeholder="Search for medicines" onkeyup="filter()"/>-->
                    <input type="text" class="searchBar" id="searchbar" onkeyup="search_input()" placeholder="Search for medicines" />
                    <!--<a class="search-btn" href="#"><i class="fas fa-search"></i></a>-->
                </div>
	<?php
	$product_array = $db_handle->runQuery("SELECT * FROM tblproduct");
	if (!empty($product_array)) { 
		foreach($product_array as $key=>$value){
	?>
		<div class="menu__container">
			<div class="menu__content">
			<form method="post" action="ngocart.php?action=add&code=<?php echo $product_array[$key]["code"]; ?>">
			<!--<div class="product-image"><img src="<?php echo $product_array[$key]["image"]; ?>"></div>-->
			<img src="<?php echo $product_array[$key]["image"]; ?>" alt="" class="menu__img">
			<div class="product-tile-footer">
			<!--<div class="product-title"><?php echo $product_array[$key]["name"]; ?></div>-->
			<h3 class="menu__name"><?php echo $product_array[$key]["name"]; ?></h3>
			<!--<div class="product-price"><?php echo "$".$product_array[$key]["price"]; ?></div>-->
			<span class="menu__preci">Free</span>
		</div>
			
			<div class="cart-action" >
			
			<select id="quantity" name="quantity" class="product-quantity">
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
  			</select>
		
			<input type="submit" value="Add to Cart" class="btnAddAction" /></div>
			</form>

			<form action="desc.php?action=desc&code=<?php echo $product_array[$key]["code"]; ?>" method="post">
			<input type="submit" value="Description" class="btnAddAction">
			</form>
		
		</div>
	<?php
		}
	}
	?>
	</center>
	</section>
	<!--<a href="home.php">back</a>-->
</div>
</main>

<!--========== SCROLL REVEAL ==========-->
        <script src="https://unpkg.com/scrollreveal"></script>

        <!--========== MAIN JS ==========-->
        <script src="main.js"></script>

		<!--Searchbar Functionaly-->
        <script>
            // JavaScript code 
            function search_input() {
                let input = document.getElementById('searchbar').value
                input = input.toLowerCase();
                let x = document.getElementsByClassName('menu__name');
				let y = document.getElementsByClassName('menu__img');
                //let z = document.getElementsByClassName('menu__detail');
                let p = document.getElementsByClassName('menu__preci');
                let a = document.getElementsByClassName('product-quantity');
                let c = document.getElementsByClassName('btnAddAction');
				let m = document.getElementsByClassName('menu__content');


                for (i = 0; i < x.length; i++) {
                    if (!x[i].innerHTML.toLowerCase().includes(input)) {
                        x[i].style.display = "none";
						y[i].style.display = "none";
                        //z[i].style.display = "none";
                        p[i].style.display = "none";
                        a[i].style.display = "none";
                        c[i].style.display = "none";
						m[i].style.display = "none";

                    }
                    else {
                        x[i].style.display = "";
						y[i].style.display = "";
                        //z[i].style.display = "";
                        p[i].style.display = "";
                        a[i].style.display = "";
                        c[i].style.display = "";
						m[i].style.display = "";
                    }
                }
            }
        </script>
		<script>
        function call1() {
            Swal.fire({
                title: 'Phone Number',
                text: '+91-9730174926',
                imageUrl: "img/caling.svg",
                imageWidth: 400,
                imageHeight: 200,
                imageAlt: 'Custom image',
            })
        }
        function call2() {
                Swal.fire({
                    title: 'Phone Number',
                    text: '+91-9863987678',
                    imageUrl: "img/caling.svg",
                    imageWidth: 400,
                    imageHeight: 200,
                    imageAlt: 'Custom image',
                })
            }
            function call3() {
                    Swal.fire({
                        title: 'Phone Number',
                        text: '+91-8972308645',
                        imageUrl: "img/caling.svg",
                        imageWidth: 400,
                        imageHeight: 200,
                        imageAlt: 'Custom image',
                    })
                }
    </script>



</BODY>
</HTML>