<?php
date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d H:i:s', time());



echo $date;

?>