<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--========== BOX ICONS ==========-->
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/b8991598b2.js"></script>
    <script src="https://unpkg.com/boxicons@latest/dist/boxicons.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="app.js"></script>
    <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

    <!--======================Offline Code=========================-->
    <script src="offline.min.js"></script>
    <link rel="stylesheet" type="text/css" href="offline-theme-default.css">
    <link rel="stylesheet" href="offline-language-english.min.css" />

    <!--<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">-->

    <!--========== CSS ==========-->
    <link rel="stylesheet" href="homestyle.css">
    <link rel="stylesheet" href="cartstyle.css">

    <!--===================Preventing Back button==============================-->
        <script type="text/javascript">
            function preventBack() { window.history.forward(); }
            setTimeout("preventBack()", 0);
            window.onunload = function () { null };
        </script>


    <title>Medicraft</title>
</head>

<body>

    <!--===========Offline script code======================-->
    <script type="text/javascript">
        Offline.options = {
            // to check the connection status immediatly on page load.
            checkOnLoad: false,

            // to monitor AJAX requests to check connection.
            interceptRequests: true,

            // to automatically retest periodically when the connection is down (set to false to disable).
            reconnect: {
                // delay time in seconds to wait before rechecking.
                initialDelay: 3,

                // wait time in seconds between retries.
                delay: 5
            },

            // to store and attempt to remake requests which failed while the connection was down.
            requests: true
        };
    </script>

    <script>
        function signoutUser() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'center',
                showConfirmButton: true,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })

            Toast.fire({
                icon: 'warning',
                iconColor: 'red',
                title: 'Are you sure to signOut?',
                showCancelButton: true,
                confirmButtonText: 'Yes, confirm',
                cancelButtonText: 'No, cancel',
                cancelButtonColor: '#d33',
                confirmButtonColor: '#069c54',
                toast: true,
            }).then((result) => {
                if (result.isConfirmed) {
                    console.log(result);
                    firebase.auth().signOut().then(function () {
                        window.location = "index.html";
                    }, function (error) {
                        console.error('Sign Out Error', error);
                    });

                }
            })
        }
    </script>


    <!--========== SCROLL TOP ==========-->
    <a href="#" class="scrolltop" id="scroll-top">
        <i class='bx bx-chevron-up scrolltop__icon'></i>
    </a>

    <!--========== HEADER ==========-->
    <header class="l-header" id="header">
        <nav class="nav bd-container">
            <a href="#" class="nav__logo">Medicraft</a>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                    <li class="nav__item"><a href="#home" class="nav__link active-link">Home</a></li>
                    <!--<li class="nav__item"><a href="#about" class="nav__link">About</a></li>-->
                    <!--<li class="nav__item"><a href="#menu" class="nav__link">Medicines</a></li>
                    <li class="nav__item"><a href="#contact" class="nav__link">Contact us</a></li>-->
                    <!--<li class="nav__item"><a href="emergency.html" class="nav__link">Emergency Tips</a></li>-->
                    <li class="nav__item"><a id="logout" class="nav__link" onclick="signoutUser();"
                            style="cursor: pointer;">SignOut</a></li>

                    <li><i class='bx bx-moon change-theme' id="theme-button"></i></li>
                    <div class="cart-btn">
                        <!--<li class="cart"><a href="##" class="icon"><i class='bx bx-cart-alt'></i><span>0</span></a></li>-->
                        <!--<li><span class="cart-info__icon mr-lg-3"><i class="bx bx-cart-alt"><span style="color: #069c54"
                                        class="cart-items">0</i></span>-->
                        <!--<span class="item-count">2</span></li>-->
                    </div>
                </ul>
            </div>

            <div class="nav__toggle" id="nav-toggle">
                <i class='bx bx-menu'></i>
            </div>
        </nav>
    </header>

    <main class="l-main">
        <!--========== HOME ==========-->
        <section class="home" id="home">
            <div class="home__container bd-container bd-grid">
                <div class="home__data">
                    <h1 class="home__title">Medicraft</h1>
                    <h2 class="home__subtitle">You can find detail <br> description.</h2>
                </div>

                <img src="img/description.svg" alt="" class="home__img">
            </div>
        </section>


        <!--========== SERVICES ==========-->
        <section class="services section bd-container" id="services">
            <!--<span class="section-subtitle">Cold</span>-->
            <h2 class="section-title" style="color: #048654;">Description</h2>
			<br>

            <?php
				//session_start();
				require_once("dbcontroller.php");
				require('db_connection.php');
				$db_handle = new DBController();
				if(!empty($_GET["action"])) {
				switch($_GET["action"]) {
					case "desc":
					$codeee=$_GET["code"];
					//echo $codeee;
					$query8="select image,description from tblproduct where code='$codeee'";
											$result8 = mysqli_query($connection, $query8) or die(mysqli_error($connection));
											$row8= mysqli_fetch_array($result8);
                                            echo "<img src='$row8[image]' alt='$row8[image]' style=' width: 74px; height: 74px; margin-left: 48%; ' ></img>";
											echo "<p style='color:#707070; font-size: 23px;' >".$row8['description']."</p>";
					break;
					
					
					
				}
				}
			?>

            </div>
        </section>

        
        
    <!--========== FOOTER ==========-->
    <footer class="footer section bd-container">
        <div class="footer__container bd-grid">
            <div class="footer__content">
                <a href="#" class="footer__logo">Medicraft</a>
                <span class="footer__description">Buy (or) sell Medicines</span>
                <div>
                    <a href="#" class="footer__social"><i class='bx bxl-facebook'></i></a>
                    <a href="#" class="footer__social"><i class='bx bxl-instagram'></i></a>
                    <a href="#" class="footer__social"><i class='bx bxl-twitter'></i></a>
                </div>
            </div>

            <div class="footer__content">
                <h3 class="footer__title">Services</h3>
                <ul>
                    <li><a href="ngocart.php" class="footer__link">Buy Medicines</a></li>
                    <!--<li><a href="sell.html" class="footer__link">Sell Medicines</a></li>-->
                    <li><a href="ngoemergency.html" class="footer__link">Emergency Tips</a></li>
                    <li><a href="#" class="footer__link">Doctor Consultant</a></li>
                </ul>
            </div>

            <div class="footer__content">
                <h3 class="footer__title">Information</h3>
                <ul>
                    <li><a href="#" class="footer__link">Event</a></li>
                    <li><a href="contact.html" class="footer__link">Contact us</a></li>
                    <li><a href="#" class="footer__link">Privacy policy</a></li>
                    <li><a href="#" class="footer__link">Terms of services</a></li>
                </ul>
            </div>

            <div class="footer__content">
                <h3 class="footer__title">Address</h3>
                <ul>
                    <li>Chennai</li>
                    <li>Tamilnadu</li>
                    <li>123 - 456 - 789</li>
                    <li>medicraft@gmail.com</li>
                </ul>
            </div>
        </div>

        <p class="footer__copy">&#169; 2021 Medicraft. All right reserved</p>
    </footer>


    <!--========== SCROLL REVEAL ==========-->
    <script src="https://unpkg.com/scrollreveal"></script>

    <!--========== MAIN JS ==========-->
    <script src="main.js"></script>
    <!--<script src="cartmain.js"></script>-->

    <!-- The core Firebase JS SDK is always required and must be listed first -->
    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-app.js"></script>

    <!-- TODO: Add SDKs for Firebase products that you want to use
                         https://firebase.google.com/docs/web/setup#available-libraries -->
    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-analytics.js"></script>

    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-firestore.js"></script>

    <script>
        // Your web app's Firebase configuration
        // For Firebase JS SDK v7.20.0 and later, measurementId is optional
        var firebaseConfig = {
            apiKey: "AIzaSyCXbYC7VXC412C_RNwzK7m69g30PERbF2k",
            authDomain: "medicraft-24732.firebaseapp.com",
            projectId: "medicraft-24732",
            storageBucket: "medicraft-24732.appspot.com",
            messagingSenderId: "969667024588",
            appId: "1:969667024588:web:33dee27c9766162f9a5469",
            measurementId: "G-NVEYWSRK4X"
        };
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);
        firebase.analytics();
    </script>

</body>

</html>





