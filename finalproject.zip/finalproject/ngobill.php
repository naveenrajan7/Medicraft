<?php
require('db_connection.php');
$uname=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$state=$_POST['state'];
$pincode=$_POST['pincode'];

$query7="DELETE FROM temp";
							$result7 = mysqli_query($connection, $query7) or die(mysqli_error($connection));
							
$query4="select punum from purchasenumber where cond=1";
							$result4 = mysqli_query($connection, $query4) or die(mysqli_error($connection));
							$row1= mysqli_fetch_assoc($result4);
							$puno=$row1['punum'];
							$pid=(int)$puno-1;

$query="update purchasedetails set name='$uname', email='$email', phone='$phone',address='$address',state='$state',pincode='$pincode' where purchaseid='$pid'";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
header("location: ngoorderplacement.php");
?>