<?php
require('db_connection.php');
$uname=$_POST['username'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$skype=$_POST['skype'];


$query="UPDATE `doctor` SET `email`='$email', mobile='$phone', skype='$skype' WHERE docname='$uname'";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));

echo "<script>
								alert('Updated');
									window.location.href='admin.php';
</script>";



?>