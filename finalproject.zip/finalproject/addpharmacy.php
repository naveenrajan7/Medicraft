<?php
require('db_connection.php');
$uname=$_POST['username'];
$pass=$_POST['password'];






$query="insert into pharmacy values('$uname','$pass')";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
echo "<script>
						alert('Pharmacy Added');
								window.location.href='admin.php';
							</script>";
						//echo "success"; 
?>
