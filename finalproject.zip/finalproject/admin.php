<?php
if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location:../index.html');
    exit;
}
?>

<?php
    session_start();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="contactstyle.css" />

    <!--========== BOX ICONS ==========-->
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/b8991598b2.js"></script>
    <script src="https://unpkg.com/boxicons@latest/dist/boxicons.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="app.js"></script>
    <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

    <!--======================Offline Code=========================-->
    <script src="offline.min.js"></script>
    <link rel="stylesheet" type="text/css" href="offline-theme-default.css">
    <link rel="stylesheet" href="offline-language-english.min.css" />

    <!--<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">-->

    <!--========== CSS ==========-->
    <link rel="stylesheet" href="homestyle.css">
    <link rel="stylesheet" href="cartstyle.css">
    <link rel="stylesheet" href="admin.css">

    <title>Medicraft</title>

    <!--===================Preventing Back button==============================-->
        <script type="text/javascript">
            function preventBack() { window.history.forward(); }
            setTimeout("preventBack()", 0);
            window.onunload = function () { null };
        </script>

</head>

<body>

    <!--===========Offline script code======================-->
    <script type="text/javascript">
        Offline.options = {
            // to check the connection status immediatly on page load.
            checkOnLoad: false,

            // to monitor AJAX requests to check connection.
            interceptRequests: true,

            // to automatically retest periodically when the connection is down (set to false to disable).
            reconnect: {
                // delay time in seconds to wait before rechecking.
                initialDelay: 3,

                // wait time in seconds between retries.
                delay: 5
            },

            // to store and attempt to remake requests which failed while the connection was down.
            requests: true
        };
    </script>

    <script>
        function signoutUser() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'center',
                showConfirmButton: true,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })

            Toast.fire({
                icon: 'warning',
                iconColor: 'red',
                title: 'Are you sure to signOut?',
                showCancelButton: true,
                confirmButtonText: 'Yes, confirm',
                cancelButtonText: 'No, cancel',
                cancelButtonColor: '#d33',
                confirmButtonColor: '#069c54',
                toast: true,
            }).then((result) => {
                if (result.isConfirmed) {
                    console.log(result);
                    firebase.auth().signOut().then(function () {
                        window.location = "administrator.html";
                    }, function (error) {
                        console.error('Sign Out Error', error);
                    });

                }
            })
        }
    </script>



    <!--========== SCROLL TOP ==========-->
    <a href="#" class="scrolltop" id="scroll-top">
        <i class='bx bx-chevron-up scrolltop__icon'></i>
    </a>

    <!--========== HEADER ==========-->
    <header class="l-header" id="header">
        <nav class="nav bd-container">
            <a href="#" class="nav__logo">Medicraft</a>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                    <li class="nav__item"><a href="#home" class="nav__link active-link">Home</a></li>
                    <li class="nav__item"><a href="#services" class="nav__link">Admin</a></li>
                    <li class="nav__item"><a href="#menu" class="nav__link">Orders</a></li>
                    <li class="nav__item"><a href="#stock" class="nav__link">Stocks</a></li>
                    <li class="nav__item"><a id="logout" class="nav__link" onclick="signoutUser();"
                            style="cursor: pointer;">SignOut</a></li>

                    <li><i class='bx bx-moon change-theme' id="theme-button"></i></li>
                </ul>
            </div>

            <div class="nav__toggle" id="nav-toggle">
                <i class='bx bx-menu'></i>
            </div>
        </nav>
    </header>

    <main class="l-main">
        <!--========== HOME ==========-->
        <section class="home" id="home">
            <div class="home__container bd-container bd-grid">
                <div class="home__data">
                    <h1 class="home__title">Medicraft</h1>
                    <h2 class="home__subtitle" style="text-transform:capitalize;"> Welcome, <?php echo $_SESSION['name']; ?> to <br> Admin panel.</h2>
                    <a href="addadmin.html" class="buttons">Add Admin</a>
					<a href="adddoctor.html" class="buttons">Add Doctor</a>
					<br><br><a href="addorg.html" class="buttons">Add Organisation</a>
					<a href="addpharmacy.html" class="buttons">Add Pharmacy</a></br></br>
					<br><br><a href="adminmain.html" class="buttons">Validation and Stock Update</a>
					<br><br><a href="deletemedicine.html" class="buttons">Delete Medicine</a>
					<a href="editmed.php" class="buttons">Edit Medicine</a>
                </div>

                <img src="img/admin.svg" alt="" class="home__img">
            </div>
        </section>

        <!--========== SERVICES ==========-->
        <section class="services section bd-container" id="services">
            <span class="section-subtitle">Administrator</span>
            <!--<h2 class="section-title">Members</h2>-->
            <div class="main-content">
                <div class="wrapper">

                    <table class="tb1-full">
                        <tr>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
						<?php
					require('db_connection.php');
					//$name=$_POST['medname'];
					$query7="select * from users where desg='admin'";
							$result7 = mysqli_query($connection, $query7) or die(mysqli_error($connection));
							
							while($row7 = mysqli_fetch_array($result7)){
								
							
					?>
                    
                        <tr>
                            <td><?php echo $row7['username'];?></td>
                            <td><?php echo $row7['mobile'];?></td>
                            <td><?php echo $row7['email'];?></td>
                            <td>
                                <a href="changepassword.html" class="btn-primary">Change Password</a>
                                <a href="updateadmin.html" class="btn-secondary">Update Admin</a>
                                <a href="deleteadmin.html" class="btn-danger">Delete Admin</a>
                            </td>
                        </tr>
							<?php }?>
                       
                    </table>

                </div>
            </div>
			<!----------doctor-->
			<section class="services section bd-container" id="services">
            <span class="section-subtitle">Doctor</span>
            <!--<h2 class="section-title">Members</h2>-->
            <div class="main-content">
                <div class="wrapper">

                    <table class="tb1-full">
                        <tr>
                            <th>Doctor Name</th>
                            <th>Phone</th>
                            
							<th>Availability</th>
                            <th>Actions</th>
							
                        </tr>
						<?php
					require('db_connection.php');
					//$name=$_POST['medname'];
					$query8="select * from doctor";
							$result8 = mysqli_query($connection, $query8) or die(mysqli_error($connection));
							
							while($row8 = mysqli_fetch_array($result8)){
								
							
					?>
                    
                        <tr>
                            <td><?php echo $row8['docname'];?></td>
                            <td><?php echo $row8['mobile'];?></td>
                            
							<td><?php echo $row8['availability'];?></td>
                            <td>
                                <a href="docchangepassword.html" class="btn-primary">Change Password</a>
                                <a href="docupdateadmin.html" class="btn-secondary">Update Doctor</a>
                                <a href="docdeleteadmin.html" class="btn-danger">Delete Doctor</a>
                            </td>
                        </tr>
							<?php }?>
                       
                    </table>

                </div>
            </div>
            
        <!--========== MENU ==========-->
        <section class="menu section bd-container" id="menu">
            <span class="section-subtitle">Purchase Orders</span>
            <!--<h2 class="section-title">Medicines available</h2>-->
            
			 <div class="main-content">
                <div class="wrapper">
				<form action="admin.php" method="POST">
				<div class="forms-container">
				
                        <center><input type="text" class="searchBar" name="pid" placeholder="Purchase ID" required />
                    
				<button class="btn-primary" type="submit" style="background-color:#069c54; cursor: pointer; font-weight: normal; border-radius: 50px; outline: none;">Get Details</button> </center>
				</form></div>

            <div class="main-content">
                <div class="wrapper">
            
                    <table class="tb1-full">
					<th>Items</th>
				<th>Qty</th>
					
					<?php
					require('db_connection.php');
					//Turn off error reporting
						error_reporting(0);
					$pid=$_POST['pid'];
					

							$query3="SELECT DISTINCT name,purdate FROM purchasedetails where purchaseid='$pid'";
							$result3 = mysqli_query($connection, $query3) or die(mysqli_error($connection));
							$row3= mysqli_fetch_assoc($result3);
							$name=$row3['name'];
							$date=$row3['purdate'];
							//echo $name;
							//echo "<h3>" . $name . "</h3>";
							//products
							$query4="SELECT DISTINCT items FROM purchasedetails where purchaseid='$pid'";
							$result4 = mysqli_query($connection, $query4) or die(mysqli_error($connection));
							while($row4 = mysqli_fetch_array($result4))
							{
								$items=$row4['items'];
								
								echo "<tr>";
							echo "<td>" . $items . "</td>";
							
								
								$query5="SELECT SUM(qty) FROM purchasedetails where items='$items' and purchaseid='$pid' ";
								$result5 = mysqli_query($connection, $query5) or die(mysqli_error($connection));
								
							while($row5 = mysqli_fetch_array($result5))
							{//echo "<br>";
								
								echo "<td>" . $row5['SUM(qty)'] . "</td>";
								echo "<br>";
								echo "</tr>";
							
							}
								
							}
							?>
                        
                       
                    </table>
					</div></div>
					<?php
					
				 echo "<h4>Customer Name: ". $name ."</h4>";
				 echo "<h4>Purchase Date: ". $date ."</h4>";
				 $query6="SELECT DISTINCT totalamt FROM purchasedetails where purchaseid='$pid'";
							$result6 = mysqli_query($connection, $query6) or die(mysqli_error($connection));
							$row6= mysqli_fetch_assoc($result6);
							//echo "<br>";
							echo "<h4>Total Amount: Rs.". $row6['totalamt'] ."</h4>";
							//echo $row4['totalamt'];
				 ?>
            
                </div>
            </div>
        </section>
		
		
		<!--========== Get purchase order by date ==========-->
        <section class="menu section bd-container" id="menu">
            <span class="section-subtitle">Purchase Orders By Date</span>
            <!--<h2 class="section-title">Medicines available</h2>-->
            
			 <div class="main-content">
                <div class="wrapper">
				<form action="admin.php" method="POST">
				<div class="forms-container">
				
                        <center><input type="text" class="searchBar" name="fromdate" placeholder="yyyy-mm-dd" required />
                    To <input type="text" class="searchBar" name="todate" placeholder="yyyy-mm-dd" required />
				<button class="btn-primary" type="submit" style="background-color:#069c54; cursor: pointer; font-weight: normal; border-radius: 50px; outline: none;">Get Details</button> </center>
				</form></div>

            <div class="main-content">
                <div class="wrapper">
            
                    <table class="tb1-full">
					<th>Name</th>
					<th>Purchase Date and Time</th>
				<th>Total Amount</th>
				<th>Purchase ID</th>
					
					<?php
					require('db_connection.php');
					//Turn off error reporting
						//error_reporting(0);
					$fromdate=$_POST['fromdate'];
					$todate=$_POST['todate'];

							$query9="SELECT DISTINCT name,purdate,totalamt,purchaseid FROM purchasedetails where purdate BETWEEN '$fromdate 12:00:00' AND '$todate 23:30:00'";
							$result9 = mysqli_query($connection, $query9) or die(mysqli_error($connection));
							while($row9 = mysqli_fetch_array($result9))
							{
							echo"<tr>";
							echo "<td>". $row9['name'] ."</td>";
							echo "<td>". $row9['purdate'] ."</td>";
							echo "<td>". $row9['totalamt'] ."</td>";
							echo "<td>". $row9['purchaseid'] ."</td>";
							echo"</tr>";
							}
                       ?>
					   
                    </table>

					</div></div>
					
            
                </div>
            </div>
        </section>
		<!--========== STOCK by name ==========-->
        <section class="menu section bd-container" id="menu">
            <span class="section-subtitle">Stock by name</span>
            <!--<h2 class="section-title">Medicines available</h2>-->

            <div class="main-content">
                <div class="wrapper">
				<form action="admin.php" method="POST">
				<div class="forms-container">
				
                        
                        <center><input type="text" class="searchBar" name="medname" placeholder="Medicine Name" required />
                    
				<button class="btn-primary" type="submit" style="background-color:#069c54; cursor: pointer; font-weight: normal; border-radius: 50px; outline: none;">Get Stock</button> </center>
				</form></div>
                    <table class="tb1-full">
                        <tr>
                            <th>ID</th>
                            <th>Medicine Name</th>
                            
                            <th>Code</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Ngo Cost</th>
                            
                        </tr>
						<?php
					require('db_connection.php');
					//Turn off error reporting
						error_reporting(0);
					$name=$_POST['medname'];
					$query2="select * from tblproduct where name='$name'";
							$result2 = mysqli_query($connection, $query2) or die(mysqli_error($connection));
							
							while($row2 = mysqli_fetch_array($result2)){
								
							
					?>
						
                        
                        <tr>
                            <td><?php echo $row2['id'];?></td>
                            <td><?php echo $row2['name'];?></td>
                            
                            <td><?php echo $row2['code'];?></td>
                            <td><?php echo $row2['price'];?></td>
                            <td><?php echo $row2['qty'];?></td>
                            <td><?php echo $row2['ngocost'];?></td>
                            
                        </tr>
					<?php }?>
                        
                       
                    </table>
            
                </div>
            </div>
        </section>
<!--========== STOCK ==========-->
        <section class="menu section bd-container" id="stock">
            <span class="section-subtitle">Stock</span>
            <!--<h2 class="section-title">Medicines available</h2>-->

            <div class="main-content">
                <div class="wrapper">
            
                    <table class="tb1-full">
                        <tr>
                            <th>ID</th>
                            <th>Medicine Name</th>
                            
                            <th>Code</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Ngo Cost</th>
                            
                        </tr>
						<?php
					require('db_connection.php');
					$query="select * from tblproduct";
							$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
							
							while($row = mysqli_fetch_array($result)){
								
							
					?>
						
                        
                        <tr>
                            <td><?php echo $row['id'];?></td>
                            <td><?php echo $row['name'];?></td>
                            
                            <td><?php echo $row['code'];?></td>
                            <td><?php echo $row['price'];?></td>
                            <td><?php echo $row['qty'];?></td>
                            <td><?php echo $row['ngocost'];?></td>
                            
                        </tr>
					<?php }?>
                        
                       
                    </table>
            
                </div>
            </div>
        </section>
        

    <!--========== FOOTER ==========-->
    <footer class="footer section bd-container">
        <div class="footer__container bd-grid">
            <div class="footer__content">
                <a href="#" class="footer__logo">Medicraft</a>
                <span class="footer__description">Buy (or) sell Medicines</span>
                <div>
                    <a href="#" class="footer__social"><i class='bx bxl-facebook'></i></a>
                    <a href="#" class="footer__social"><i class='bx bxl-instagram'></i></a>
                    <a href="#" class="footer__social"><i class='bx bxl-twitter'></i></a>
                </div>
            </div>


            <div class="footer__content">
                <h3 class="footer__title">Information</h3>
                <ul>
                    <li><a href="#" class="footer__link">Event</a></li>
                    <li><a href="contact.html" class="footer__link">Contact us</a></li>
                    <li><a href="#" class="footer__link">Privacy policy</a></li>
                    <li><a href="#" class="footer__link">Terms of services</a></li>
                </ul>
            </div>

            <div class="footer__content">
                <h3 class="footer__title">Address</h3>
                <ul>
                    <li>Chennai</li>
                    <li>Tamilnadu</li>
                    <li>123 - 456 - 789</li>
                    <li>medicraft@gmail.com</li>
                </ul>
            </div>
        </div>

        <p class="footer__copy">&#169; 2021 Medicraft. All right reserved</p>
    </footer>

    <!--========== SCROLL REVEAL ==========-->
    <script src="https://unpkg.com/scrollreveal"></script>

    <!--========== MAIN JS ==========-->
    <script src="main.js"></script>

    <!-- The core Firebase JS SDK is always required and must be listed first -->
    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-app.js"></script>

    <!-- TODO: Add SDKs for Firebase products that you want to use
                         https://firebase.google.com/docs/web/setup#available-libraries -->
    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-analytics.js"></script>

    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-firestore.js"></script>

    <script>
        // Your web app's Firebase configuration
        // For Firebase JS SDK v7.20.0 and later, measurementId is optional
        var firebaseConfig = {
            apiKey: "AIzaSyCXbYC7VXC412C_RNwzK7m69g30PERbF2k",
            authDomain: "medicraft-24732.firebaseapp.com",
            projectId: "medicraft-24732",
            storageBucket: "medicraft-24732.appspot.com",
            messagingSenderId: "969667024588",
            appId: "1:969667024588:web:33dee27c9766162f9a5469",
            measurementId: "G-NVEYWSRK4X"
        };
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);
        firebase.analytics();
    </script>

</body>

</html>