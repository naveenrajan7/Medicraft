const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});

//<!------------Google Authentication with firebase(User Login)----------------------->

function GoogleLogin() {
  var provider = new firebase.auth.GoogleAuthProvider();
  firebase.auth().signInWithPopup(provider).then(function (result) {
    //window.location="home.php";
    //console.log(result);
    //const db = firebase.database();
    const user = firebase.auth().currentUser;
    if (user !== null) {   
      const displayName = user.displayName;
      const email = user.email;
      const photoURL = user.photoURL;
      const lastSignin = user.metadata.lastSignInTime;
      const emailVerified = user.emailVerified;
      const signInMethod = user.providerData[0].providerId;
      const uid = user.providerData[0].uid;
      //const autoId = db.push().key
      firebase.database().ref("Google Login").child(uid).set({
        Name: displayName,
        Email: email,
        Photo : photoURL,
        EmailVerified: emailVerified,
        LastSignIn: lastSignin,
        SignInMethod: signInMethod
      });
       setTimeout(function(){
           homepage();
       }, 2000);
    }
  }).catch(function(error) {
    var errorMessage=error.message;
    alert(errorMessage);
  })
}

function homepage() {
  window.location="home.php";
}


//<!------------------------Github Authenticate with Firebase(User Login)---------------->
function GithubLogin() {
  var provider = new firebase.auth.GithubAuthProvider();
  firebase.auth().signInWithPopup(provider).then(function (result) {
    //window.location="home.php";
    //console.log(result);
    const user = firebase.auth().currentUser;
    if (user !== null) {   
      const displayName = user.displayName;
      const email = user.email;
      const photoURL = user.photoURL;
      const lastSignin = user.metadata.lastSignInTime;
      const signInMethod = user.providerData[0].providerId;
      const emailVerified = user.emailVerified;
      const uid = user.providerData[0].uid;

      firebase.database().ref("Github Login").child(uid).set({
        Name: displayName,
        Email: email,
        Photo : photoURL,
        LastSignIn: lastSignin,
        SignInMethod: signInMethod,
        EmailVerified: emailVerified
      });
    }
    setTimeout(function(){
           window.location="home.php";
       }, 2000);
  }).catch(function(error) {
    var errorMessage=error.message;
    alert(errorMessage);
  })
}


//<!-------------------------Google Authenticate with Firebase(Ngo Login)----------------->
function NgoGoogleLogin() {
  var provider = new firebase.auth.GoogleAuthProvider();
  firebase.auth().signInWithPopup(provider).then(function () {
    window.location="ngohome.html";
  }).catch(function(error) {
    var errorMessage=error.message;
    alert(errorMessage);
  })
}

//<!-------------------------Github Authenticate with Firebase(Ngo Login)----------------->
function NgoGithubLogin() {
  var provider = new firebase.auth.GithubAuthProvider();
  firebase.auth().signInWithPopup(provider).then(function () {
    window.location="ngohome.html";
  }).catch(function(error) {
    var errorMessage=error.message;
    alert(errorMessage);
  })
}


//<!-------------------------Microsoft Authenticate with Firebase----------------->
function MicrosoftLogin() {
  var provider = new firebase.auth.OAuthProvider('microsoft.com');
  provider.setCustomParameters({
  prompt: "consent",
  tenant: "f8cdef31-a31e-4b4a-93e4-5f571e91255a",
})

  firebase.auth().signInWithPopup(provider)
  .then((result) => {
    // IdP data available in result.additionalUserInfo.profile.
    /** @type {firebase.auth.OAuthCredential} */
    var credential = result.credential;

    // OAuth access and id tokens can also be retrieved:
    var accessToken = credential.accessToken;
    var idToken = credential.idToken;
    window.location="home.php";
  })
  .catch((error) => {
    // Handle error.
    alert(error);
  });
}

//<!-------------------------User Logout----------------->
function SignOut() {
  firebase.auth().signOut().then(function() {
  window.location="login.html";
}, function(error) {
  console.error('Sign Out Error', error);
});
}


//<!-------------------------Ngo Logout----------------->
function SignOuts() {
  firebase.auth().signOut().then(function() {
    window.location="ngo.html";
}, function(error) {
  console.error('Sign Out Error', error);
});
}


//<!------------Facebook Authentication with firebase-------------------------->
function FacebookLogin() {
  var provider = new firebase.auth.FacebookAuthProvider();
  firebase
  .auth()
  .signInWithPopup(provider)
  .then((result) => {
    /** @type {firebase.auth.OAuthCredential} */
    var credential = result.credential;

    // The signed-in user info.
    var user = result.user;

    // This gives you a Facebook Access Token. You can use it to access the Facebook API.
    var accessToken = credential.accessToken;

    window.location="home.php";
  })
  .catch((error) => {
    // Handle Errors here.
    var errorCode = error.code;
    var errorMessage = error.message;
    // The email of the user's account used.
    var email = error.email;
    // The firebase.auth.AuthCredential type that was used.
    var credential = error.credential;

    // ...
    alert(error);
  });
}

//<!------------Yahoo Authentication with firebase-------------------------->

function YahooLogin() {
  var provider = new firebase.auth.OAuthProvider('yahoo.com');
  firebase.auth().signInWithPopup(provider)
  .then((result) => {
    // IdP data available in result.additionalUserInfo.profile
    // ...

    /** @type {firebase.auth.OAuthCredential} */
    const credential = result.credential;

    // Yahoo OAuth access token and ID token can be retrieved by calling:
    var accessToken = credential.accessToken;
    var idToken = credential.idToken;
    //window.location="home.php";
    const user = firebase.auth().currentUser;
    if (user !== null) {   
      const displayName = user.displayName;
      const email = user.email;
      const photoURL = user.photoURL;
      const lastSignin = user.metadata.lastSignInTime;
      const emailVerified = user.emailVerified;
      const signInMethod = user.providerData[0].providerId;
      const uid = user.providerData[0].uid;

      firebase.database().ref("Yahoo Login").child(uid).set({
        Name: displayName,
        Email: email,
        Photo : photoURL,
        EmailVerified: emailVerified,
        LastSignIn: lastSignin,
        SignInMethod: signInMethod
      });
    }
    setTimeout(function(){
           window.location="home.php";
       }, 2000);

  })
  .catch((error) => {
    // Handle error.
    alert(error);

  });
}

//<!-------------------------Yahoo Authenticate with Firebase(Ngo Login)----------------->

function NgoYahooLogin() {
  var provider = new firebase.auth.OAuthProvider('yahoo.com');
  firebase.auth().signInWithPopup(provider)
  .then((result) => {
    // IdP data available in result.additionalUserInfo.profile
    // ...

    /** @type {firebase.auth.OAuthCredential} */
    const credential = result.credential;

    // Yahoo OAuth access token and ID token can be retrieved by calling:
    var accessToken = credential.accessToken;
    var idToken = credential.idToken;
    window.location="ngohome.html";
    //console.log(result);

  })
  .catch((error) => {
    // Handle error.
    alert(error);

  });
}

//<!-------------------------Twitter Authenticate with Firebase----------------->
function TwitterLogin() {
  var provider = new firebase.auth.TwitterAuthProvider();
  firebase.auth().signInWithPopup(provider).then(function (result) {
    const user = firebase.auth().currentUser;
    if (user !== null) {   
      const displayName = user.displayName;
      const email = user.email;
      const photoURL = user.photoURL;
      const lastSignin = user.metadata.lastSignInTime;
      const emailVerified = user.emailVerified;
      const signInMethod = user.providerData[0].providerId;
      const uid = user.providerData[0].uid;
      firebase.database().ref("Twitter Login").child(uid).set({
        Name: displayName,
        Email: email,
        Photo : photoURL,
        EmailVerified: emailVerified,
        LastSignIn: lastSignin,
        SignInMethod: signInMethod
      });
       setTimeout(function(){
           homepage();
       }, 2000);
    }
    console.log(result);
  }).catch(function(error) {
    var errorMessage=error.message;
    alert(errorMessage);
  })
}

