<?php
require('db_connection.php');
$uname=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$message=$_POST['message'];

$query="insert into contact values('$uname','$email','$phone','$message')";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
echo "<script>
        alert('Thank you for your kind feedback 😊');
        window.location.href='doctorhome.php';
    </script>";
//header("location: home.php");

?>
