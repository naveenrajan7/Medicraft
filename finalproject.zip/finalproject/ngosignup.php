<?php
require('db_connection.php');
$orgname=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$pass=$_POST['password'];


$query="insert into ngodetails values('$orgname','$email','$phone','$pass')";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
///echo "success";
header("location: ngo.html");
?>