<?php
if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location:../index.html');
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <link rel="stylesheet" href="sellstyle.css" />
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

    <!--======================Offline Code=========================-->
    <script src="offline.min.js"></script>
    <link rel="stylesheet" type="text/css" href="offline-theme-default.css">
    <link rel="stylesheet" href="offline-language-english.min.css" />
</head>

<style>
    input[type="date"]::-webkit-calendar-picker-indicator {
  cursor: pointer;
  border-radius: 4px;
  margin-right: 2px;
  opacity: 0.6;
  filter: invert(0.8);
}

input[type="date"]::-webkit-calendar-picker-indicator:hover {
  opacity: 1
}
}

</style>

<body>
    <!--===========Offline script code======================-->
    <script type="text/javascript">
        Offline.options = {
            // to check the connection status immediatly on page load.
            checkOnLoad: false,

            // to monitor AJAX requests to check connection.
            interceptRequests: true,

            // to automatically retest periodically when the connection is down (set to false to disable).
            reconnect: {
                // delay time in seconds to wait before rechecking.
                initialDelay: 3,

                // wait time in seconds between retries.
                delay: 5
            },

            // to store and attempt to remake requests which failed while the connection was down.
            requests: true
        };
    </script>


    <div class="container">
        <div class="form">
            <div class="contact-info">
                <a href="admin.php" class="title">Medicraft</a>
                <!--<h3 class="title">Sell Medicines</h3>-->
                <p class="text">
                    You can also sell all the medicines. We offer amazing features in our websites.
                </p>
                <img src="img/details.svg" class="image" style="height: 400px; width:350px;" alt="" />
            </div>

            <div class="contact-form">
                <span class="circle one"></span>
                <span class="circle two"></span>
				<form method="POST" action="editmed.php">
                   
                    <div class="input-container">
                        <input type="text" id="refid" name="refid" class="input" required/>
                        <label for="">CODE</label>
                        <span>CODE</span>
                    </div>
                   
					
                    <input type="submit" onclick="send();" value="Validate" class="btn" />
                </form>
				<?php
				
				//Turn off error reporting
				error_reporting(0);
				$count=0;
					require('db_connection.php');
					$refid=$_POST['refid'];
					$query="SELECT id,name,image,qty,price,ngocost,description FROM `tblproduct` WHERE code='$refid'";
					$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
				$rows = mysqli_fetch_array($result);
					$count = mysqli_num_rows($result);
					
						?>




                <form  action="updatemed.php" method="post" enctype="multipart/form-data" id="myForm">
                    <h3 class="title">Details</h3>
                    <div class="input-container">
                         <p style="color:white">ID</p><input type="text" id="id" name="id" class="input" value="<?php echo $rows['id'];?>" required/>

                    </div>
                   <div class="input-container">
                         <p style="color:white">Name</p><input type="text" id="medname" name="medname" class="input" value="<?php echo $rows['name'];?>" >

                    </div>
					<div class="input-container">
                         <p style="color:white">Image</p><input type="text" id="image" name="image" class="input" value="<?php echo $rows['image'];?>"required/>
                        
                    </div>
					<div class="input-container">
                         <p style="color:white">Quantity</p><input type="number" id="qty" name="qty" class="input" value="<?php echo $rows['qty'];?>" required/>
                        
                    </div>
					<div class="input-container">
                         <p style="color:white">Price</p><input type="float" id="price" name="price" class="input" value="<?php echo $rows['price'];?>"required/>
                       
                    </div>
					<div class="input-container">
                         <p style="color:white">NGO Cost</p><input type="float" id="ngocost" name="ngocost" class="input" value="<?php echo $rows['ngocost'];?>"required/>
                       
                    </div>
					<div class="input-container">
                         <p style="color:white">Description</p><input type="text" id="des" name="des" class="input" value="<?php echo $rows['description'];?>" >

                    </div>
                   
					<input type="hidden" value="<?php echo $refid;?>" name="refid"/>
                    <input type="submit" onclick="send();" value="Add Details" class="btn" />
					
                </form>
				
            </div>
        </div>
    </div>

    <script src="contactapp.js"></script>
</body>

</html>