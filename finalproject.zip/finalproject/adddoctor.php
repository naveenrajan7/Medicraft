<?php
require('db_connection.php');
$uname=$_POST['username'];
$pass=$_POST['password'];
$des=$_POST['des'];
$skype=$_POST['skype'];
$phone=$_POST['phone'];
$email=$_POST['email'];

$sql_u = "SELECT * FROM doctor WHERE email='$email'";
$sql_e = "SELECT * FROM doctor WHERE mobile='$phone'";
$res_u = mysqli_query($connection, $sql_u);
$res_e = mysqli_query($connection, $sql_e);

if (mysqli_num_rows($res_u) > 0) {
  	//echo '<script>alert("Sorry... email already taken")</script>'; 
    echo "<script>
        alert('Sorry...email already taken');
        window.location.href='adddoctor.html';
    </script>";
}if(mysqli_num_rows($res_e) > 0){
  	//echo '<script>alert("Sorry... phone number already taken")</script>';
     echo "<script>
        alert('Sorry...phone number already taken');
        window.location.href='adddoctor.html';
    </script>";
 
}else {

$query="insert into doctor values('$uname','$pass','$des','$skype','$phone','$email','Available')";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
echo "<script>
								alert('Doctor Added');
									window.location.href='admin.php';
								</script>";
}
?>
