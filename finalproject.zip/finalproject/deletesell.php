<?php  
 require('db_connection.php');
$refno = $_POST['refno'];

$query="DELETE FROM `sellmedicine` WHERE referenceno='$refno'";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));

echo "<script>
								alert('Deleted');
									window.location.href='delivery.php';
</script>";

?>