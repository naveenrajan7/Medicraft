<?php
require('db_connection.php');
$refid=$_POST['refid'];

$query="UPDATE sellmedicine SET verified=1 WHERE referenceno='$refid' ";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
echo '<script>alert("Validated")</script>';
echo "<script>location.href = 'adminmain.html';</script>";
?>