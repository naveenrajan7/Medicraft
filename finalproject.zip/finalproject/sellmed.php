<?php
$msg="";
require('db_connection.php');
$medname=$_POST['medname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$expdate=$_POST['date'];
$quantity=$_POST['quantity'];
$pickadd=$_POST['address'];
$brand=$_POST['brand'];
$referenceid = mt_rand(1000,9999);
date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d H:i:s', time());


$medimage = $_FILES["image"]["name"]; 
    $tempname = $_FILES["image"]["tmp_name"];     
        $folder = "images/".$medimage; 
		$purchaseimage = $_FILES["purchaseimage"]["name"]; 
    $tempname1= $_FILES["purchaseimage"]["tmp_name"];     
        $folder1 = "images/purchase_bill/".$purchaseimage; 
$query="insert into sellmedicine values('$medname','$email','$phone','$expdate','$quantity','$pickadd','$medimage','$brand','$purchaseimage',$referenceid,0,0,0,0,0,'$date')";
if (move_uploaded_file($tempname, $folder))  { 
            $msg = "Image uploaded successfully"; 
        }else{ 
            $msg = "Failed to upload image"; 
      } 
	  
	  if (move_uploaded_file($tempname1, $folder1))  { 
            $msg = "Image uploaded successfully"; 
        }else{ 
            $msg = "Failed to upload image"; 
      } 
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));

echo "<script>
							alert('Done your reference ID is $referenceid');
									window.location.href='home.php';
								</script>";
							//echo "success";
?>