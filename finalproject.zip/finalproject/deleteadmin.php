<?php
require('db_connection.php');
$uname=$_POST['username'];




$query="DELETE FROM `users` WHERE username='$uname'";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));

echo "<script>
								alert('User Deleted');
									window.location.href='admin.php';
</script>";



?>