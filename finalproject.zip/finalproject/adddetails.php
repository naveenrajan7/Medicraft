<?php
require('db_connection.php');
$medname=$_POST['medname'];
$brand=$_POST['brand'];
$expdate=$_POST['expdate'];
$quantity=$_POST['quantity'];
$cost=$_POST['cost'];
$refid=$_POST['refid'];
$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyz';
$medid=substr(str_shuffle($permitted_chars), 0, 10);
$query1="select qty from tblproduct where name='$medname' ";
$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
$count = mysqli_num_rows($result1);
if($count==1)
{
	//$rows=$result1->fetch_assoc()
	$row= mysqli_fetch_array($result1);
	$newqty=$row['qty']+$quantity;
	
	$query2="update tblproduct set qty='$newqty',price='$cost' where name='$medname'";
	$result2 = mysqli_query($connection, $query2) or die(mysqli_error($connection));
	
	
	$query3="update sellmedicine set expirydate='$expdate',added='1',medname='$medname',quantity='$quantity' where referenceno='$refid'";
	$result3 = mysqli_query($connection, $query3) or die(mysqli_error($connection));
}
else
{
	


$query="insert into tblproduct values('','$medname','$medid','product-images/no-image.png','$quantity','$cost',0,0)";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
}
echo "<script>
					alert('Updated Stock');
					window.location.href='admin.php';
								</script>";
	//echo "sucess";
?>