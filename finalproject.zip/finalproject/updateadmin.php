<?php
require('db_connection.php');
$uname=$_POST['username'];
$email=$_POST['email'];
$phone=$_POST['phone'];



$query="UPDATE `users` SET `email`='$email', mobile='$phone' WHERE username='$uname' and desg='admin'";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));

echo "<script>
								alert('Updated');
									window.location.href='admin.php';
</script>";



?>