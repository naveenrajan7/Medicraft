<?php
if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location:../index.html');
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--========== BOX ICONS ==========-->
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/b8991598b2.js"></script>
    <script src="https://unpkg.com/boxicons@latest/dist/boxicons.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="app.js"></script>
    <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

    <!--======================Offline Code=========================-->
    <script src="offline.min.js"></script>
    <link rel="stylesheet" type="text/css" href="offline-theme-default.css">
    <link rel="stylesheet" href="offline-language-english.min.css" />

    <!--<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">-->

    <!--========== CSS ==========-->
    <link rel="stylesheet" href="homestyle.css">
    <link rel="stylesheet" href="cartstyle.css">
    <link rel="stylesheet" href="admin.css">

    <title>Medicraft</title>

    <script type="text/javascript">
            function preventBack() { window.history.forward(); }
            setTimeout("preventBack()", 0);
            window.onunload = function () { null };
        </script>

</head>

<body>

    <!--===========Offline script code======================-->
    <script type="text/javascript">
        Offline.options = {
            // to check the connection status immediatly on page load.
            checkOnLoad: false,

            // to monitor AJAX requests to check connection.
            interceptRequests: true,

            // to automatically retest periodically when the connection is down (set to false to disable).
            reconnect: {
                // delay time in seconds to wait before rechecking.
                initialDelay: 3,

                // wait time in seconds between retries.
                delay: 5
            },

            // to store and attempt to remake requests which failed while the connection was down.
            requests: true
        };
    </script>

    <script>
        function signoutUser() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'center',
                showConfirmButton: true,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })

            Toast.fire({
                icon: 'warning',
                iconColor: 'red',
                title: 'Are you sure to signOut?',
                showCancelButton: true,
                confirmButtonText: 'Yes, confirm',
                cancelButtonText: 'No, cancel',
                cancelButtonColor: '#d33',
                confirmButtonColor: '#069c54',
                toast: true,
            }).then((result) => {
                if (result.isConfirmed) {
                    console.log(result);
                    firebase.auth().signOut().then(function () {
                        window.location = "deliverylogin.html"; 
                    }, function (error) {
                        console.error('Sign Out Error', error);
                    });

                }
            })
        }
    </script>



    <!--========== SCROLL TOP ==========-->
    <a href="#" class="scrolltop" id="scroll-top">
        <i class='bx bx-chevron-up scrolltop__icon'></i>
    </a>

    <!--========== HEADER ==========-->
    <header class="l-header" id="header">
        <nav class="nav bd-container">
            <a href="#" class="nav__logo">Medicraft</a>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                    <li class="nav__item"><a href="#home" class="nav__link active-link">Home</a></li>
                    <li class="nav__item"><a href="#menu" class="nav__link">Orders</a></li>
                    <li class="nav__item"><a id="logout" class="nav__link" onclick="signoutUser();"
                            style="cursor: pointer;">SignOut</a></li>

                    <li><i class='bx bx-moon change-theme' id="theme-button"></i></li>
                </ul>
            </div>

            <div class="nav__toggle" id="nav-toggle">
                <i class='bx bx-menu'></i>
            </div>
        </nav>
    </header>

    <main class="l-main">
        <!--========== HOME ==========-->
        <section class="home" id="home">
            <div class="home__container bd-container bd-grid">
                <div class="home__data">
                    <h1 class="home__title">Medicraft</h1>
                    <h2 class="home__subtitle">Welcome to <br> Delivery page.</h2>
                    <!--<a href="addadmin.html" class="buttons">Add Admin</a>-->
                </div>

                <img src="img/delivery.svg" alt="" class="home__img">
            </div>
        </section>
		 <div class="main-content">
                <div class="wrapper">
				<form action="pharmacyvalidate.php" method="POST">
				<div class="forms-container">
				
                        <center><h3>Enter Reference no. To Vailidate Data</h3>
                        <input type="text" class="searchBar" name="referenceno" placeholder="Reference No" required />
                    <input type="text" class="searchBar" name="amt" placeholder="Buyed Amount" required />
					<input type="text" class="searchBar" name="comment" placeholder="Comment"  />
				<button class="btn-primary" type="submit" style="background-color:#069c54; cursor: pointer; font-weight: normal; border-radius: 50px; outline: none;">Vailidate</button> </center>
				</form></div>
				<br>
				<div class="main-content">
                <div class="wrapper">
				<form action="deletesell.php" method="POST">
				<div class="forms-container">
				
                        <center><h3>Enter Reference no. To Delete Data</h3>
                         <input type="text" class="searchBar" name="refno" placeholder="Reference No" required />
                    
				<button class="btn-primary" type="submit" style="background-color:#069c54; cursor: pointer; font-weight: normal; border-radius: 50px; outline: none;">Delete</button> </center>
				</form></div>
            
            <!--========== MENU ==========-->
            <section class="menu section bd-container" id="menu">
                <span class="section-subtitle">Orders</span>
                <!--<h2 class="section-title">Medicines available</h2>-->

                <div class="main-content">
                    <div class="wrapper">

                        <table class="tb1-full">
                            <tr>
							    <th>Reference No</th>
                                <th>Medicine Name</th>
                                <th>Brand</th>
                                <th>Email</th>
                                <th>Phone</th>
                                
                                <th>Quantity</th>
								<th>Expiry Date</th>
								<th>Sell Date and Time</th>
                                
                                
                            </tr>
							<?php
					require('db_connection.php');
					//$name=$_POST['medname'];
					$query="select * from sellmedicine where pharmacyvalidate='0'";
							$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
							
							while($row = mysqli_fetch_array($result)){
								
							
					?>

                            <tr>
                                <td><?php echo $row['referenceno'];?></td>
                                <td><?php echo $row['medname'];?></td>
                                <td><?php echo $row['brand'];?></td>
                                <td><?php echo $row['email'];?></td>
                                <td><?php echo $row['phone'];?></td>
                                <td><?php echo $row['quantity'];?></td>
                                <td><?php echo $row['expirydate'];?></td>
                                <td><?php echo $row['selldate'];?></td>
                            </tr>
							<?php } ?>
                         

                        </table>

                    </div>
                </div>
            </section>



            <!--========== FOOTER ==========-->
            <footer class="footer section bd-container">
                <div class="footer__container bd-grid">
                    <div class="footer__content">
                        <a href="#" class="footer__logo">Medicraft</a>
                        <span class="footer__description">Buy (or) sell Medicines</span>
                        <div>
                            <a href="#" class="footer__social"><i class='bx bxl-facebook'></i></a>
                            <a href="#" class="footer__social"><i class='bx bxl-instagram'></i></a>
                            <a href="#" class="footer__social"><i class='bx bxl-twitter'></i></a>
                        </div>
                    </div>


                    <div class="footer__content">
                        <h3 class="footer__title">Information</h3>
                        <ul>
                            <li><a href="#" class="footer__link">Event</a></li>
                            <li><a href="contact.html" class="footer__link">Contact us</a></li>
                            <li><a href="#" class="footer__link">Privacy policy</a></li>
                            <li><a href="#" class="footer__link">Terms of services</a></li>
                        </ul>
                    </div>

                    <div class="footer__content">
                        <h3 class="footer__title">Address</h3>
                        <ul>
                            <li>Chennai</li>
                            <li>Tamilnadu</li>
                            <li>123 - 456 - 789</li>
                            <li>medicraft@gmail.com</li>
                        </ul>
                    </div>
                </div>

                <p class="footer__copy">&#169; 2021 Medicraft. All right reserved</p>
            </footer>

            <!--========== SCROLL REVEAL ==========-->
            <script src="https://unpkg.com/scrollreveal"></script>

            <!--========== MAIN JS ==========-->
            <script src="main.js"></script>
            <!--<script src="cartmain.js"></script>-->

            <!-- The core Firebase JS SDK is always required and must be listed first -->
            <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-app.js"></script>

            <!-- TODO: Add SDKs for Firebase products that you want to use
                         https://firebase.google.com/docs/web/setup#available-libraries -->
            <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-analytics.js"></script>

            <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-auth.js"></script>
            <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-firestore.js"></script>

            <script>
                // Your web app's Firebase configuration
                // For Firebase JS SDK v7.20.0 and later, measurementId is optional
                var firebaseConfig = {
                    apiKey: "AIzaSyCXbYC7VXC412C_RNwzK7m69g30PERbF2k",
                    authDomain: "medicraft-24732.firebaseapp.com",
                    projectId: "medicraft-24732",
                    storageBucket: "medicraft-24732.appspot.com",
                    messagingSenderId: "969667024588",
                    appId: "1:969667024588:web:33dee27c9766162f9a5469",
                    measurementId: "G-NVEYWSRK4X"
                };
                // Initialize Firebase
                firebase.initializeApp(firebaseConfig);
                firebase.analytics();
            </script>

</body>

</html>