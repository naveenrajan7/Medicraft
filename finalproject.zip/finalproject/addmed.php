<?php
require('db_connection.php');
session_start();
$refid=$_POST['refid'];
$query="SELECT medname,brand,quantity FROM `sellmedicine` WHERE referenceno='$refid' and verified=1";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
$rows=$result->fetch_assoc()
$_SESSION['medname'] = $rows['medname'];
$_SESSION['brand'] =$rows['brand'];
$_SESSION['quantity'] = $rows['quantity'];

?>