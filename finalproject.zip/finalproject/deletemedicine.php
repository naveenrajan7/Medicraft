<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--========== BOX ICONS ==========-->
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/b8991598b2.js"></script>
    <script src="https://unpkg.com/boxicons@latest/dist/boxicons.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="app.js"></script>
    <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

    <!--======================Offline Code=========================-->
    <script src="offline.min.js"></script>
    <link rel="stylesheet" type="text/css" href="offline-theme-default.css">
    <link rel="stylesheet" href="offline-language-english.min.css" />

    <!--<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">-->

    <!--========== CSS ==========-->
    <link rel="stylesheet" href="homestyle.css">
    <link rel="stylesheet" href="cartstyle.css">
    <link rel="stylesheet" href="admin.css">

    <title>Medicraft</title>
</head>

<body>

    <!--===========Offline script code======================-->
    <script type="text/javascript">
        Offline.options = {
            // to check the connection status immediatly on page load.
            checkOnLoad: false,

            // to monitor AJAX requests to check connection.
            interceptRequests: true,

            // to automatically retest periodically when the connection is down (set to false to disable).
            reconnect: {
                // delay time in seconds to wait before rechecking.
                initialDelay: 3,

                // wait time in seconds between retries.
                delay: 5
            },

            // to store and attempt to remake requests which failed while the connection was down.
            requests: true
        };
    </script>

    
    </script>


    <!--========== SCROLL TOP ==========-->
    <a href="#" class="scrolltop" id="scroll-top">
        <i class='bx bx-chevron-up scrolltop__icon'></i>
    </a>

    <!--========== HEADER ==========-->
    <header class="l-header" id="header">
        <nav class="nav bd-container">
            <a href="#" class="nav__logo">Medicraft</a>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                   
                    <li class="nav__item"><a href="#menu" class="nav__link">Orders</a></li>
                    <li class="nav__item"><a id="logout" class="nav__link" href="admin.php"
                            style="cursor: pointer;">Back</a></li>

                    <li><i class='bx bx-moon change-theme' id="theme-button"></i></li>
                </ul>
            </div>

            <div class="nav__toggle" id="nav-toggle">
                <i class='bx bx-menu'></i>
            </div>
        </nav>
    </header>

    <main class="l-main">
        <!--========== HOME ==========-->
        <section class="home" id="home">
            <div class="home__container bd-container bd-grid">
                <div class="home__data">
                    <h1 class="home__title">Medicraft</h1>
                    
                    <!--<a href="addadmin.html" class="buttons">Add Admin</a>-->
                </div>
<div class="main-content">
                <div class="wrapper">
				<form action="deletemed.php" method="POST">
				<div class="forms-container">
				
                        <center><h3>Enter Reference no. To Delete Medicine</h3><br>
                         <input type="text" class="searchBar" placeholder="Reference NO" id="refid" name="refid" class="input" required/>
                    
				<button class="btn-primary" type="submit" style="background-color:#069c54; cursor: pointer; font-weight: normal; border-radius: 50px; outline: none;">Delete Medicine</button> </center>
				</form></div>
				<BR><center><h3>SCROLL DOWN TO SEE STOCK</h3></center>
                
            </div>
        </section>
		<!--========== STOCK ==========-->
        <section class="menu section bd-container" id="menu">
            <span class="section-subtitle">Stock</span>
            <!--<h2 class="section-title">Medicines available</h2>-->

            <div class="main-content">
                <div class="wrapper">
            
                    <table class="tb1-full">
                        <tr>
                            <th>ID</th>
                            <th>Medicine Name</th>
                            
                            <th>Code</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Ngo Cost</th>
                            
                        </tr>
						<?php
					require('db_connection.php');
					$query="select * from tblproduct";
							$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
							
							while($row = mysqli_fetch_array($result)){
								
							
					?>
						
                        
                        <tr>
                            <td><?php echo $row['id'];?></td>
                            <td><?php echo $row['name'];?></td>
                           
                            <td><?php echo $row['code'];?></td>
                            <td><?php echo $row['price'];?></td>
                            <td><?php echo $row['qty'];?></td>
                            <td><?php echo $row['ngocost'];?></td>
                            
                        </tr>
					<?php }?>
                        
                       
                    </table>
            
                </div>
            </div>
        </section>
        
				
							 


    <script>
        function send() {
            var refid = document.getElementById('refdid').value;
            
			
            if (refid == '' ) {
                swal("Alert!", "Please check the missing fields", "warning");
            }
        }
    </script>

    
</body>

</html>