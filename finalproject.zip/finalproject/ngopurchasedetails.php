<?php
require('db_connection.php');
							$amt=$_POST['amt'];
							$query4="select punum from purchasenumber where cond=1";
							$result4 = mysqli_query($connection, $query4) or die(mysqli_error($connection));
							$row1= mysqli_fetch_assoc($result4);
							$puno=$row1['punum'];
							$pid=$puno+1;
							$query3="update purchasedetails set totalamt='$amt' where purchaseid='$puno'";
							$result3 = mysqli_query($connection, $query3) or die(mysqli_error($connection));
							$query2="update purchasenumber set punum='$pid' where cond=1";
							$result2 = mysqli_query($connection, $query2) or die(mysqli_error($connection));
							//session_destroy();
							header("location: ngocart.php?action=empty");
							?>