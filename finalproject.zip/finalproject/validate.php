<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--========== BOX ICONS ==========-->
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/b8991598b2.js"></script>
    <script src="https://unpkg.com/boxicons@latest/dist/boxicons.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="app.js"></script>
    <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

    <!--======================Offline Code=========================-->
    <script src="offline.min.js"></script>
    <link rel="stylesheet" type="text/css" href="offline-theme-default.css">
    <link rel="stylesheet" href="offline-language-english.min.css" />

    <!--<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">-->

    <!--========== CSS ==========-->
    <link rel="stylesheet" href="homestyle.css">
    <link rel="stylesheet" href="cartstyle.css">
    <link rel="stylesheet" href="admin.css">

    <title>Medicraft</title>
</head>

<body>

    <!--===========Offline script code======================-->
    <script type="text/javascript">
        Offline.options = {
            // to check the connection status immediatly on page load.
            checkOnLoad: false,

            // to monitor AJAX requests to check connection.
            interceptRequests: true,

            // to automatically retest periodically when the connection is down (set to false to disable).
            reconnect: {
                // delay time in seconds to wait before rechecking.
                initialDelay: 3,

                // wait time in seconds between retries.
                delay: 5
            },

            // to store and attempt to remake requests which failed while the connection was down.
            requests: true
        };
    </script>

    
    </script>


    <!--========== SCROLL TOP ==========-->
    <a href="#" class="scrolltop" id="scroll-top">
        <i class='bx bx-chevron-up scrolltop__icon'></i>
    </a>

    <!--========== HEADER ==========-->
    <header class="l-header" id="header">
        <nav class="nav bd-container">
            <a href="#" class="nav__logo">Medicraft</a>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                   
                    <li class="nav__item"><a href="#menu" class="nav__link">Orders</a></li>
                    <li class="nav__item"><a id="logout" class="nav__link" href="adminmain.html"
                            style="cursor: pointer;">Back</a></li>

                    <!--<li><i class='bx bx-moon change-theme' id="theme-button"></i></li>-->
                </ul>
            </div>

            <div class="nav__toggle" id="nav-toggle">
                <i class='bx bx-menu'></i>
            </div>
        </nav>
    </header>

    <main class="l-main">
        <!--========== HOME ==========-->
        <section class="home" id="home">
            <div class="home__container bd-container bd-grid">
                <div class="home__data">
                    <h1 class="home__title">Medicraft</h1>
                    <h2 class="home__subtitle">Welcome to <br> Vailidate page.</h2>
                    <!--<a href="addadmin.html" class="buttons">Add Admin</a>-->
                </div>

                <img src="img/delivery.svg" alt="" class="home__img">
            </div>
        </section>
		
				<br>
				<div class="main-content">
                <div class="wrapper">
				<form action="validate1.php" method="POST">
				<div class="forms-container">
				
                        <center><h3>Enter Reference no. To Vailidate Data</h3><br>
                         <input type="text" class="searchBar" placeholder="Reference NO" id="refid" name="refid" class="input" required/>
                    
				<button class="btn-primary" type="submit" style="background-color:#069c54; cursor: pointer; font-weight: normal; border-radius: 50px; outline: none;">Vailidate</button> </center>
				</form></div>

            <div class="contact-form">
			<script src="contactapp.js"></script>
	<section class="menu section bd-container" id="menu">
                <span class="section-subtitle">Orders</span>
                <!--<h2 class="section-title">Medicines available</h2>-->

                <div class="main-content">
                    <div class="wrapper">

                        <table class="tb1-full">
                            <tr>
							    <th>Reference No</th>
                                <th>Medicine Name</th>
                                <th>Brand</th>
                                <th>Email</th>
                                <th>Phone</th>
                                
                                <th>Quanntity</th>
								<th>Expiry Date</th>
                                
                                
                            </tr>
							<?php
					require('db_connection.php');
					//$name=$_POST['medname'];
					$query="select * from sellmedicine where pharmacyvalidate='1' and verified=0 and added=0";
							$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
							
							while($row = mysqli_fetch_array($result)){
								
							
					?>

                            <tr>
                                <td><?php echo $row['referenceno'];?></td>
                                <td><?php echo $row['medname'];?></td>
                                <td><?php echo $row['brand'];?></td>
                                <td><?php echo $row['email'];?></td>
                                <td><?php echo $row['phone'];?></td>
                                <td><?php echo $row['quantity'];?></td>
                                <td><?php echo $row['expirydate'];?></td>
                                
                            </tr>
							<?php } ?>
                         

                        </table>

                    </div>
                </div>
            </section>
                
				
				 


    <script>
        function send() {
            var refid = document.getElementById('refdid').value;
            
			
            if (refid == '' ) {
                swal("Alert!", "Please check the missing fields", "warning");
            }
        }
    </script>

    
</body>

</html>