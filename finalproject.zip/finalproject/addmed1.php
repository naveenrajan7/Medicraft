<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <link rel="stylesheet" href="sellstyle.css" />
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

    <!--======================Offline Code=========================-->
    <script src="offline.min.js"></script>
    <link rel="stylesheet" type="text/css" href="offline-theme-default.css">
    <link rel="stylesheet" href="offline-language-english.min.css" />
</head>

<style>
    input[type="date"]::-webkit-calendar-picker-indicator {
  cursor: pointer;
  border-radius: 4px;
  margin-right: 2px;
  opacity: 0.6;
  filter: invert(0.8);
}

input[type="date"]::-webkit-calendar-picker-indicator:hover {
  opacity: 1
}


</style>

<body>
    <!--===========Offline script code======================-->
    <script type="text/javascript">
        Offline.options = {
            // to check the connection status immediatly on page load.
            checkOnLoad: false,

            // to monitor AJAX requests to check connection.
            interceptRequests: true,

            // to automatically retest periodically when the connection is down (set to false to disable).
            reconnect: {
                // delay time in seconds to wait before rechecking.
                initialDelay: 3,

                // wait time in seconds between retries.
                delay: 5
            },

            // to store and attempt to remake requests which failed while the connection was down.
            requests: true
        };
    </script>


    <div class="container">
        <div class="form">
            <div class="contact-info">
                <a href="admin.php" class="title">Medicraft</a>
                <!--<h3 class="title">Sell Medicines</h3>-->
                <p class="text">
                    You can also sell all the medicines. We offer amazing features in our websites.
                </p>
                <img src="img/details.svg" class="image" style="height: 400px; width:350px;" alt="" />
            </div>

            <div class="contact-form">
                <span class="circle one"></span>
                <span class="circle two"></span>
				<form method="POST" action="addmed1.php">
                   
                    <div class="input-container">
                        <input type="text" id="refid" name="refid" class="input" required/>
                        <label for="">Reference ID</label>
                        <span>Reference ID</span>
                    </div>
                   
					
                    <input type="submit" onclick="send();" value="Validate" class="btn" />
                </form>
				<?php
				
				//Turn off error reporting
				error_reporting(0);
				$count=0;
					require('db_connection.php');
					$refid=$_POST['refid'];
					$query="SELECT medname,brand,quantity,expirydate,comment FROM `sellmedicine` WHERE referenceno='$refid' and verified=1 and pharmacyvalidate=1 and added=0";
					$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
				$rows = mysqli_fetch_array($result);
					$count = mysqli_num_rows($result);
					
						?>




                <form  action="adddetails.php" method="post" enctype="multipart/form-data">
                    <h3 class="title">Details</h3>
                    <div class="input-container">
                         <p style="color:white">Medicine Name</p><input type="text" id="medname" name="medname" class="input" value="<?php echo $rows['medname'];?>" required/>

                    </div>
                   <div class="input-container">
                         <p style="color:white">Comments</p><input type="text" id="comment" name="comment" class="input" value="<?php echo $rows['comment'];?>" >

                    </div>
					<div class="input-container">
                         <p style="color:white">Brand</p><input type="text" id="brand" name="brand" class="input" value="<?php echo $rows['brand'];?>"required/>
                        
                    </div>
					<div class="input-container">
                         <p style="color:white">Expiry Date</p><input type="tel" id="expdate" name="expdate" class="input" value="<?php echo $rows['expirydate'];?>" required/>
                        
                    </div>
					<div class="input-container">
                         <p style="color:white">Quantity</p><input type="number" id="quantity" name="quantity" class="input" value="<?php echo $rows['quantity'];?>"required/>
                       
                    </div>
					<div class="input-container">
                         <p style="color:white">Cost Per Medicine</p><input type="float" id="cost" name="cost" class="input" required/>
                       
                    </div>
                   
					<input type="hidden" value="<?php echo $refid;?>" name="refid"/>
                    <input type="submit" onclick="send();" value="Add Details" class="btn" />
					<input type="submit" onclick="resetForm();" value="Clear" class="btn" />
                </form>
				
            </div>
        </div>
    </div>
 <script>
            function resetForm() {
            document.contact-form.reset();
            }
        </script>
    <script src="contactapp.js"></script>
</body>

</html>