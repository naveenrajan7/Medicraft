<?php
if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location:../index.html');
    exit;
}
?>


<html>
	<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--========== BOX ICONS ==========-->
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/b8991598b2.js"></script>
    <script src="https://unpkg.com/boxicons@latest/dist/boxicons.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="app.js"></script>
    <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

    <!--======================Offline Code=========================-->
    <script src="offline.min.js"></script>
    <link rel="stylesheet" type="text/css" href="offline-theme-default.css">
    <link rel="stylesheet" href="offline-language-english.min.css" />

    <!--<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">-->

    <!--========== CSS ==========-->
    <link rel="stylesheet" href="homestyle.css">
    <link rel="stylesheet" href="cartstyle.css">
	<link rel="stylesheet" href="notstyle.css">

  <!--===================Preventing Back button==============================-->
        <script type="text/javascript">
            function preventBack() { window.history.forward(); }
            setTimeout("preventBack()", 0);
            window.onunload = function () { null };
        </script>


    <title>Medicraft</title>
</head>

<body>
	<!--===========Offline script code======================-->
    <script type="text/javascript">
        Offline.options = {
            // to check the connection status immediatly on page load.
            checkOnLoad: false,

            // to monitor AJAX requests to check connection.
            interceptRequests: true,

            // to automatically retest periodically when the connection is down (set to false to disable).
            reconnect: {
                // delay time in seconds to wait before rechecking.
                initialDelay: 3,

                // wait time in seconds between retries.
                delay: 5
            },

            // to store and attempt to remake requests which failed while the connection was down.
            requests: true
        };
    </script>

	<!--========== SCROLL TOP ==========-->
    <a href="#" class="scrolltop" id="scroll-top">
        <i class='bx bx-chevron-up scrolltop__icon'></i>
    </a>

	

<style>
table, th, td {
  border: 1px solid black;
}
#t01 tr:nth-child(even) {
  background-color: #eee;
}
#t01 tr:nth-child(odd) {
  background-color: #fff;
}
#t01 th {
  color: white;
  background-color: #2f2e41;
}

button {
	width: 140px;
  height: 40px;
  margin: 10px;
  background-color: #2f2e41;
  color: #ffffff;
  text-transform: uppercase;
  outline: none;
  border: none;
  letter-spacing: 1px;
  box-shadow: 2px 2px 30px rgba(0, 0, 0, 0.1);
  border-radius: 4px;
  font-family: "Poppins", sans-serif;
}

h2 {
	color: #2f2e41;
}
</style>
<h1 style="color: #2f2e41"><center>ORDER PLACED</center></h1>
<h1 style="color: #2f2e41"><center>Thank you for purchasing.</center></h1>
<h2 style="color: #2f2e41"><center>Your order list</center></h2>
<center>
<img src="img/success.svg" style="hight: 20%; width: 20%;"></img>
</center>
<center>
<table style="width:40%" id="t01">

<th>Items</th>
<th>Qty</th>


<?php
require('db_connection.php');
$query="select punum from purchasenumber";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
							$row= mysqli_fetch_assoc($result);
							$puno=$row['punum'];
							$pid=(int)$puno-1;
							//echo $pid;
							//echo "<h3>" . $pid . "</h3>";
							//name
							$query1="SELECT DISTINCT name FROM purchasedetails where purchaseid='$pid'";
							$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
							$row1= mysqli_fetch_assoc($result1);
							$name=$row1['name'];
							//echo $name;
							//echo "<h3>" . $name . "</h3>";
							//products
							$query2="SELECT DISTINCT items FROM purchasedetails where purchaseid='$pid'";
							$result2 = mysqli_query($connection, $query2) or die(mysqli_error($connection));
							while($row2 = mysqli_fetch_array($result2))
							{
								$items=$row2['items'];
								
								echo "<tr>";
							echo "<td>" . $items . "</td>";
							
								
								$query3="SELECT SUM(qty) FROM purchasedetails where items='$items' and purchaseid='$pid' ";
								$result3 = mysqli_query($connection, $query3) or die(mysqli_error($connection));
								
							while($row3 = mysqli_fetch_array($result3))
							{//echo "<br>";
								//echo $row3['COUNT(DISTINCT items)'];
								echo "<td>" . $row3['SUM(qty)'] . "</td>";
								echo "<br>";
								echo "</tr>";
							
							}
								
							}
							?>
							
</table>
</center>
<center>
			<?php
				 echo "<h2>Customer Name: ". $name ."</h2>";
				 
				 $query4="SELECT DISTINCT totalamt FROM purchasedetails where purchaseid='$pid'";
							$result4 = mysqli_query($connection, $query4) or die(mysqli_error($connection));
							$row4= mysqli_fetch_assoc($result4);
							//echo "<br>";
							echo "<h2>Total Amount: Rs. ". $row4['totalamt'] ."</h2>";
							//echo $row4['totalamt'];
				 ?>
				 <!--<a href="home.php"><h3>Home</h3></a>-->
				 <a href="home.php"><button>back</button></a>
				 </center>
				 
</body>
</html>