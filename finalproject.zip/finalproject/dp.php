<?php

    $server = "sql206.epizy.com";
    $username = "epiz_28553923";
    $password = "CvxnbNyVZ4Fp0";
    $dbname = "epiz_28553923_medicraft";

    $conn = mysqli_connect($server, $username, $password, $dbname);

    if(!conn) {
        die("Connection Failed:".mysqli_connect_error());
    }
?>