<?php
if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location:../index.html');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--========== BOX ICONS ==========-->
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/b8991598b2.js"></script>
    <script src="https://unpkg.com/boxicons@latest/dist/boxicons.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="app.js"></script>
    <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

    <!--======================Offline Code=========================-->
    <script src="offline.min.js"></script>
    <link rel="stylesheet" type="text/css" href="offline-theme-default.css">
    <link rel="stylesheet" href="offline-language-english.min.css" />

    <!--<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">-->

    <!--========== CSS ==========-->
    <link rel="stylesheet" href="homestyle.css">
    <link rel="stylesheet" href="cartstyle.css">
    <link rel="stylesheet" href="admin.css">

    <title>Medicraft</title>
</head>

<body>

    <!--===========Offline script code======================-->
    <script type="text/javascript">
        Offline.options = {
            // to check the connection status immediatly on page load.
            checkOnLoad: false,

            // to monitor AJAX requests to check connection.
            interceptRequests: true,

            // to automatically retest periodically when the connection is down (set to false to disable).
            reconnect: {
                // delay time in seconds to wait before rechecking.
                initialDelay: 3,

                // wait time in seconds between retries.
                delay: 5
            },

            // to store and attempt to remake requests which failed while the connection was down.
            requests: true
        };
    </script>

    
    </script>


    <!--========== SCROLL TOP ==========-->
    <a href="#" class="scrolltop" id="scroll-top">
        <i class='bx bx-chevron-up scrolltop__icon'></i>
    </a>

    <!--========== HEADER ==========-->
    <header class="l-header" id="header">
        <nav class="nav bd-container">
            <a href="home.php" class="nav__logo">Medicraft</a>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                   
                   
                    <li class="nav__item"><a id="logout" class="nav__link" href="home.php"
                            style="cursor: pointer;">Back</a></li>
                </ul>
            </div>

            <div class="nav__toggle" id="nav-toggle">
                <i class='bx bx-menu'></i>
            </div>
        </nav>
    </header>

    <main class="l-main">
        <!--========== HOME ==========-->
        <section class="home" id="home">
            <div class="home__container bd-container bd-grid">
                <div class="home__data">
                    <h1 class="home__title">Medicraft</h1>
                    <h2 class="home__subtitle">Welcome to <br> Check Status page.</h2>
                </div>

                <img src="img/delivery.svg" alt="" class="home__img">
            </div>
        </section>
		
				<br>
				<div class="main-content">
                <div class="wrapper">
				<form action="sellstatus.php" method="POST">
				<div class="forms-container">
				
                        <center><h3>Enter Reference no. To Check Status</h3><br>
                         <input type="text" class="searchBar" placeholder="Reference NO" id="refid" name="refid" class="input" required/>
                    
				<button class="btn-primary" type="submit" style="background-color:#069c54; cursor: pointer; font-weight: normal; border-radius: 50px; outline: none;">Vailidate</button> </center>
				</form></div><br><br>
					<center>
            
   
							<?php
					require('db_connection.php');
					//Turn off error reporting
						error_reporting(0);
					$refid=$_POST['refid'];
					$count=0;
					$query="select * from sellmedicine where pharmacyvalidate=1 and referenceno='$refid'";
							$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
							$count = mysqli_num_rows($result);
							$row= mysqli_fetch_array($result);
							if($count==1)
							{
								echo "<h3 style='color:green'>Vailidated by pharmacy</h3>";
								echo "<br>";
								echo "<h3 style='color:green'> Buyed Amount:  ".$row['amount']."Rs</h3>";
								echo "<br>";
							}
							else 
							{
								echo "<h3 style='color:Red'>Pharmacy Vailidation is still on process</h3>";
								echo "<br>";
							}
							$query1="select * from sellmedicine where verified=1 and pharmacyvalidate=1  and referenceno='$refid'";
							$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
							$count1 = mysqli_num_rows($result1);
							
							if($count1==1)
							{
								echo "<h3 style='color:green'>Vailidated by Admin</h3>";
								echo "<br>";
								
							}
							else 
							{
								echo "<h3 style='color:red'>Admin Vailidation is still on process</h3>";
								echo "<br>";
							}
								
							
					?>

                        </center> 

                        

            </section>
                
				
				 


    <script>
        function send() {
            var refid = document.getElementById('refdid').value;
            
			
            if (refid == '' ) {
                swal("Alert!", "Please check the missing fields", "warning");
            }
        }
    </script>

    
</body>

</html>