<?php  
 require('db_connection.php');

if (isset($_POST['username']) and isset($_POST['password'])){
	
// Assigning POST values to variables.
$username = $_POST['username'];
$password = $_POST['password'];
$count=0;



// CHECK FOR THE RECORD FROM TABLE
$query = "SELECT * FROM `pharmacy` WHERE name='$username' and password='$password' ";
//$query1 = "SELECT * FROM `users` WHERE username='$username' and pass='$password' and desg='admin' ";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
//$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
$count = mysqli_num_rows($result);
//$count1 = mysqli_num_rows($result1);



if ($count == 1){

//echo "Login Credentials verified";
header("location: delivery.php");
}
//else if($count1 == 1){
	

//header("location: adminmain.html");
//}
else{
	
echo "<script>
								alert('Invalid username and password');
									window.location.href='deliverylogin.html';
								</script>";
//echo "Invalid Login Credentials";
}
}
?>
<html>
<body>
<form>
<input type="hidden" value="<?php echo $username?>" name="docname">

