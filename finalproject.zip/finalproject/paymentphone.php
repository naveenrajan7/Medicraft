<!DOCTYPE html>

<?php
require('db_connection.php');
$query="select punum from purchasenumber";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
							$row= mysqli_fetch_assoc($result);
							$puno=$row['punum'];
							$pid=(int)$puno-1;
							$query1="SELECT DISTINCT name FROM purchasedetails where purchaseid='$pid'";
							$result1 = mysqli_query($connection, $query1) or die(mysqli_error($connection));
							$row1= mysqli_fetch_assoc($result1);
							$name=$row1['name'];
							//echo "<h2>Customer Name: ". $name ."</h2>";
				 
				 $query4="SELECT DISTINCT totalamt FROM purchasedetails where purchaseid='$pid'";
							$result4 = mysqli_query($connection, $query4) or die(mysqli_error($connection));
							$row4= mysqli_fetch_assoc($result4);
				 ?>
							
							
							
							
							
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css" />
    <title>PAYMENT</title>
    <link rel="shortcut icon" href="img/logo.ico" type="image/x-icon">

    <!--===================Preventing Back button==============================-->
        <script type="text/javascript">
            function preventBack() { window.history.forward(); }
            setTimeout("preventBack()", 0);
            window.onunload = function () { null };
        </script>

</head>

<style>
    .sign-in-form {
        text-align: center;
    }
    .input-field {
        margin-left: 25%;
    }
</style>

<body>
    <div class="container">
        <div class="forms-container">
            <div class="signin-signup">
                <div class="sign-in-form">
                    <h2 class="title">Payment</h2>
                    <div class="input-field">
                        <i class="fas fa-phone-alt"></i>
                        <input type="tel" id="phoneNumber" placeholder="Enter +91**********" value="+91<?php echo $_POST['phone'];?>" required />
                        
						<div id="recaptcha-container"></div>
                    </div>
					<h3>Customer Name:<?php echo $name;?></h3>
					<h3 style="color:red">Total Amount: Rs. <?php echo $row4['totalamt'];?></h3>
                    <br>
                    <br>
                    <br>
                    <button id="sign-in-button" class="btn solid" onclick="submitPhoneNumberAuth()">
                        PAY 
                    </button>
                    <div class="input-field">
                        <i class="fas fa-lock"></i>
                        <input type="text" id="code" placeholder="Code" required />
                    </div>
                    <button id="confirm-code" class="btn solid" onclick="submitPhoneNumberAuthCode()">
                        ENTER CODE
                    </button>
                </div>
            </div>
        </div>

        <div class="panels-container">
            <div class="panel left-panel">
                <img src="img/otp.svg" class="image" alt="" />
            </div>
        </div>
    </div>

    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-app.js"></script>

    <!-- TODO: Add SDKs for Firebase products that you want to use 
                                     https://firebase.google.com/docs/web/setup#available-libraries -->
    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-analytics.js"></script>

    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.2.6/firebase-firestore.js"></script>


    <script>
        // Paste the config your copied earlier
        var firebaseConfig = {
            apiKey: "AIzaSyCXbYC7VXC412C_RNwzK7m69g30PERbF2k",
            authDomain: "medicraft-24732.firebaseapp.com",
            projectId: "medicraft-24732",
            storageBucket: "medicraft-24732.appspot.com",
            messagingSenderId: "969667024588",
            appId: "1:969667024588:web:33dee27c9766162f9a5469",
            measurementId: "G-NVEYWSRK4X"
        };

        firebase.initializeApp(firebaseConfig);

        // Create a Recaptcha verifier instance globally
        // Calls submitPhoneNumberAuth() when the captcha is verified
        window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier(
            "recaptcha-container",
            {
                size: "normal",
                callback: function (response) {
                    submitPhoneNumberAuth();
                }
            }
        );

        // This function runs when the 'sign-in-button' is clicked
        // Takes the value from the 'phoneNumber' input and sends SMS to that phone number
        function submitPhoneNumberAuth() {
            var phoneNumber = document.getElementById("phoneNumber").value;
            var appVerifier = window.recaptchaVerifier;
            firebase
                .auth()
                .signInWithPhoneNumber(phoneNumber, appVerifier)
                .then(function (confirmationResult) {
                    window.confirmationResult = confirmationResult;
                })
                .catch(function (error) {
                    console.log(error);
                });
        }

        // This function runs when the 'confirm-code' button is clicked
        // Takes the value from the 'code' input and submits the code to verify the phone number
        // Return a user object if the authentication was successful, and auth is complete
        function submitPhoneNumberAuthCode() {
            var code = document.getElementById("code").value;
            confirmationResult
                .confirm(code)
                .then(function (result) {
                    var user = result.user;
                    console.log(user);
                    window.location = "orderplacement.php";
                })
                .catch(function (error) {
                    console.log(error);
                });
        }

        //This function runs everytime the auth state changes. Use to verify if the user is logged in
        firebase.auth().onAuthStateChanged(function (user) {
            if (user) {
                console.log("USER LOGGED IN");
            } else {
                // No user is signed in.
                console.log("USER NOT LOGGED IN");
            }
        });
    </script>
</body>

</html>