<?php
require('db_connection.php');
$uname=$_POST['username'];

$pass=$_POST['newpass'];


$query="UPDATE `doctor` SET `password`='$pass' WHERE docname='$uname'";
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));

echo "<script>
								alert('Password changed');
									window.location.href='admin.php';
</script>";



?>